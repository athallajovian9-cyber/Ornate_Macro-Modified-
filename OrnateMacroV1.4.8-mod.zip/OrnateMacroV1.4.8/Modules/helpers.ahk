#Persistent
#SingleInstance Force
SetWorkingDir %A_ScriptDir%
#InstallKeybdHook
#UseHook
#MaxThreadsPerHotkey 2
#MaxThreads 255
#HotkeyInterval 100
#MaxHotkeysPerInterval 200
#HotkeyModifierTimeout 1000

global DEFAULT_MOUSE_SPEED := 3

global yOffsets
global xOffsets
yOffsets := {}
xOffsets := {}

yOffsets["1050_96"]  := -0.002
yOffsets["953_96"]  := -0.005
yOffsets["1080_96"]  := 0.000
yOffsets["1080_120"] := -0.005
yOffsets["1440_96"]  := 0.010
yOffsets["1440_120"]  := 0.000

xOffsets["1680_96"]  := -0.002

DllCall("SetProcessDPIAware")
CoordMode, Mouse, Screen
CoordMode, Pixel, Screen

GetClientArea(hwnd, ByRef x, ByRef y, ByRef w, ByRef h) {
    VarSetCapacity(r, 16, 0)
    DllCall("GetClientRect",  "Ptr", hwnd, "Ptr", &r)
    left   := NumGet(r, 0, "Int")
    top    := NumGet(r, 4, "Int")
    right  := NumGet(r, 8, "Int")
    bottom := NumGet(r, 12, "Int")
    w := right - left,  h := bottom - top
    DllCall("ClientToScreen", "Ptr", hwnd, "IntP", left, "IntP", top)
    x := left, y := top
}

getGameWinID() {
    WinGet, pid, PID, ahk_exe RobloxPlayerBeta.exe
    return pid ? WinExist("ahk_pid " pid) : 0
}

SafeMoveRelative(xRatio, yRatio, speed := "") {
    yRatio += GetYAdjust()
    xRatio += GetXAdjust()
    hwnd := getGameWinID()
    if !hwnd
        return
    GetClientArea(hwnd, cx, cy, cw, ch)
    moveX := cx + Round(xRatio * cw)
    moveY := cy + Round(yRatio * ch)
    if (speed = "")
        speed := DEFAULT_MOUSE_SPEED

    MouseMove, %moveX%, %moveY%, %speed%
}

SafeClickRelative(xRatio, yRatio) {
	yRatio += GetYAdjust()
	xRatio += GetXAdjust()
    hwnd := getGameWinID()
    if !hwnd
        return
    GetClientArea(hwnd, cx, cy, cw, ch)
    clickX := cx + Round(xRatio * cw)
    clickY := cy + Round(yRatio * ch)
    Click, clickX, clickY
}

getMouseCoord(axis) {
    hwnd := getGameWinID()
    if (!hwnd)
        return 0
    GetClientArea(hwnd, cx, cy, cw, ch)
    MouseGetPos, mX, mY
    relX := (mX - cx) / cw
    relY := (mY - cy) / ch
    if (axis = "y")
        relY += GetYAdjust()
	if (axis = "x")
        relX += GetXAdjust()
    return (axis = "x") ? relX : relY
}

getPixelColorRelative(xRatio, yRatio) {
    yRatio += GetYAdjust()
	xRatio += GetXAdjust()

    hwnd := getGameWinID()
    if (!hwnd)
        return ""
    GetClientArea(hwnd, cx, cy, cw, ch)
    px := cx + Round(xRatio * cw)
    py := cy + Round(yRatio * ch)
    PixelGetColor, clr, px, py, RGB
    return clr+0
}

IsPixelColorCloseArea(xRatio, yRatio, targetColor, tolHex := 0x050505, radiusRatio := 0.003) {
    clamp := Func("ClampRatio")
    offsets := [ -radiusRatio, 0, radiusRatio ]

    for _, dx in offsets {
        for _, dy in offsets {
            xi := clamp.Call(xRatio + dx)
            yi := clamp.Call(yRatio + dy)
            clr := getPixelColorRelative(xi, yi)
            if Abs(clr - targetColor) <= tolHex
                return true
        }
    }
    return false
}

ClampRatio(val) {
    return (val < 0) ? 0
         : (val > 1) ? 1
         : val
}


ScrollTP() {
	depX := 0.5
	depY := 0.34
		if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
			depY += 0.035
		}
		if ( A_ScreenHeight = 953 && A_ScreenDPI = 96 ) {
			depY += 0.01
		}
	SafeMoveRelative(depX, depY)
	Send, {WheelUp}
	Sleep, 50
}


UITop() {
    uiUniversal("UUUUUUUUUUUUUUUUUU", 0)
}

IsPixelColorClose(xRatio, yRatio, targetColor, tol := 5) {
    clr := getPixelColorRelative(xRatio, yRatio)

    r1 := (clr >> 16) & 0xFF
    g1 := (clr >>  8) & 0xFF
    b1 :=  clr        & 0xFF

    r2 := (targetColor >> 16) & 0xFF
    g2 := (targetColor >>  8) & 0xFF
    b2 :=  targetColor       & 0xFF

    return ( Abs(r1 - r2) <= tol
          && Abs(g1 - g2) <= tol
          && Abs(b1 - b2) <= tol )
}

GetYAdjust() {
    global yOffsets
    key := A_ScreenHeight "_" A_ScreenDPI
    return yOffsets.HasKey(key) ? yOffsets[key] : 0.0
}

GetXAdjust() {
    global xOffsets
    key := A_ScreenWidth "_" A_ScreenDPI
    return xOffsets.HasKey(key) ? xOffsets[key] : 0.0
}


EquipmentPick() {
        UiUniversal("U", 0)
        Send, {2}
        UiUniversal("DRR055555", 1, 0)

}

LeftOfPan() {
    depX := 0.378
    depY := 0.800
    if (A_ScreenWidth = 1680 && A_ScreenDPI = 96) {
        depX += 0.002
    }
	if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
		depY -= 0.015
	}
    return IsPixelColorClose(depX, depY, 0x8C8C8C, 5)
}

RightOfPan() {
	depX := 0.623
	depY := 0.800
		if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
			depY -= 0.015
		}
	if ( A_ScreenWidth = 1856 && A_ScreenDPI = 96 ) {
			depX -= 0.002
		}
	; Both original branches assigned 0xF9E36E. The intended 768-height pixel
	; colour cannot be derived from source; it requires a live game sample.
	target := 0xF9E36E
		
	return IsPixelColorCloseArea(depX, depY, target, 0x080808, 0.002)
}

CenterOfP() {
    depX  := 0.476
    depY  := 0.912
    if (A_ScreenWidth = 1680 && A_ScreenDPI = 96) {
        depX += 0.002
    }
    if (A_ScreenWidth = 1856 && A_ScreenDPI = 96) {
        depX += 0.002
    }
    if (A_ScreenWidth = 1366 && A_ScreenDPI = 96) {
        depX += 0.002
    }
    if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
        depY -= 0.021 
    }
    if (A_ScreenHeight = 953 && A_ScreenDPI = 96) {
        depY -= 0.005
    }
    return IsPixelColorCloseArea(depX, depY, 0x353533, 0x000002, 0.002)
}

CenterOfT() {
	; FIXED: this function used to compound-assign undeclared baseX/baseY names.
	; AHK v1 silently treated them as empty, so the adjustment did not take effect.
	depX := 0.437
	depY := 0.900
	if ( A_ScreenWidth = 1856 && A_ScreenDPI = 96 ) {
		depX += 0.006
	}
	if ( A_ScreenHeight = 953 && A_ScreenDPI = 96 ) {
		depY -= 0.006
	}
	if (A_ScreenWidth = 1366 && A_ScreenDPI = 96) {
		depX -= 0.00145
	}
	if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
		depY -= 0.020
	}
	return IsPixelColorCloseArea(depX, depY, 0x353533, 0x000002, 0.002)
}

MerchantM1() {
	depX := 0.850
	depY := 0.650
	if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
			depY += 0.04
		}
	SafeMoveRelative(depX, depY)
}

MerchantM2() {
	depX := 0.780
	depY := 0.420
		if (A_ScreenWidth = 1366 && A_ScreenDPI = 96) {
			depX -= 0.055
		}
	SafeMoveRelative(depX, depY)
}

InvSearchBar() {
	depX := 0.615
	depY := 0.660
	if (A_ScreenHeight = 1050 && A_ScreenDPI = 96) {
		depY -= 0.01
	}
	if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
			depY -= 0.15
	}
	if (A_ScreenWidth = 1680 && A_ScreenDPI = 96) {
		depX += 0.02
	}
	if (A_ScreenWidth = 1366 && A_ScreenDPI = 96) {
			depX += 0.045
	}
	if ( A_ScreenHeight = 953 && A_ScreenDPI = 96 ) {
		depY -= 0.05
	}
	if ( A_ScreenWidth = 1856 && A_ScreenDPI = 96 ) {
		depX += 0.01
	}
	SafeMoveRelative(depX, depY)
}

InvTotemClick() {
	depX := 0.350
	depY := 0.715
	if (A_ScreenHeight = 1050 && A_ScreenDPI = 96) {
		depY -= 0.01
	}
	if (A_ScreenWidth = 1680 && A_ScreenDPI = 96) {
		depX -= 0.025
	}
	if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
			depY -= 0.125
	}
	if (A_ScreenWidth = 1366 && A_ScreenDPI = 96) {
			depX -= 0.065
	}
	if ( A_ScreenHeight = 953 && A_ScreenDPI = 96 ) {
		depY -= 0.045
	}
	if ( A_ScreenWidth = 1856 && A_ScreenDPI = 96 ) {
		depX -= 0.005
	}
	SafeMoveRelative(depX, depY)
}

HotbarMove() {
	depX := 0.305
	depY := 0.985
		if (A_ScreenWidth = 1680 && A_ScreenDPI = 96) {
			depX -= 0.02
		}
		if (A_ScreenHeight = 1050 && A_ScreenDPI = 96) {
			depY -= 0.00
		}
		if (A_ScreenWidth = 1366 && A_ScreenDPI = 96) {
			depX -= 0.06
		}
		if (A_ScreenHeight = 768 && A_ScreenDPI = 96) {
			depY -= 0.01
		}
    SafeMoveRelative(depX, depY)
}

FortuneTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DD555550", 1, 0)
}

CrystalCavernTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDD555550", 1, 0)
}

AzuraliteOasisTP() {
    UITop()
    ScrollTP()
    uiUniversal("5DDD555550", 1, 0)
}


SunsetBeachTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDD555550", 1, 0)
}

OvergrownTP() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDD555550", 1, 0)
}

FortuneDeltaTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDD555550", 1, 0)
}

VolcanicSandsTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDD555550", 1, 0)
}

WindsweptBeachTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDD555550", 1, 0)
}

TheMagmaFurnaceTP() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDDD555550", 1, 0)
}

InfernalHeartTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDDD555550", 1, 0)
}

RotwoodSwampTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDDDD555550", 1, 0)
}


FrostbiteRiverTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDDDDD555550", 1, 0)
}

FrostbiteWaterfallTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDDDDDD555550", 1, 0)
}

FrozenPeakTp() {
    UITop()
    ScrollTP()
    uiUniversal("5DDDDDDDDDDDDDD555550", 1, 0)
}

DoubleCheckPanEmpty() {
	Click, down
	Sleep 1700
	Click, up
}

GamepassSell() {
	uiUniversal("UU", 0)     ;
	Sleep, 100              
	Send, {g}
	Sleep, 100
	uiUniversal("D0", 1, 0) 
        Sleep, 100
        Send, {g}
}


Loadout1() {
        EquipmentPick() 
	uiUniversal("UUU0555555555555", 1)
	Send, {2}
        Sleep, 2000
}

Loadout2() {
        EquipmentPick() 
	uiUniversal("UU0555555555555", 1)
	Send, {2}
        Sleep, 2000
}

Loadout3() {
        EquipmentPick() 
	uiUniversal("U0555555555555", 1)
	Send, {2}
        Sleep, 2000
}


ResetGroundPrompt() {
	Send, {Space down}
	Sleep 50
	Send, {Space up}
}

ClickDailyPrompt() {
	SafeMoveRelative(0.5, 0.710)
    Sleep 100
        Loop 5 {
            Send, {Click down}
            Sleep, 50
            Send, {Click up}
        }
    Sleep 100
}

ClickReconnectPrompt() {
	SafeMoveRelative(0.55, 0.605)
    Sleep 100
        Loop 5 {
            Send, {Click down}
            Sleep, 50
            Send, {Click up}
        }
    Sleep 100
}

FocusRoblox() {
    if WinExist("ahk_exe RobloxPlayerBeta.exe") {
        WinActivate
        WinWaitActive, ahk_exe RobloxPlayerBeta.exe, , 1
        return true
    }
    return false
}

repeatKey(key := "nil", count := 1, delay := 50) {

    global SavedSpeed

    if (key = "nil") {
        return
    }

    Loop, %count% {
        Send {%key%}
        Sleep, % (SavedSpeed = "Ultra" ? (delay - 25) : SavedSpeed = "Max" ? (delay - 30) : delay)
    }

}

sendKeybind() {
    SendInput, {sc02B}
}

sleepAmount(fastTime, slowTime) {

    global SavedSpeed

    Sleep, % (SavedSpeed != "Stable") ? fastTime : slowTime

}

BuyItem() {
	uiUniversal("U0", 1)
}

BuyItemX2() {
	uiUniversal("U05UU05", 0, 1)
}

BuyItemConfirm() {
	uiUniversal("50D05", 1, 0)
}

; directional sequence encoder/executor
; if you're going to modify the calls to this make sure you know what you're doing (ui navigation has some odd behaviours)
uiUniversal(order := 0, exitUi := 1, openUi := 1, continuous := 0, spam := 0, spamCount := 30, delayTime := 50, mode := "universal", index := 0, dir := "nil", itemType := "nil") {

    global UINavKeybind

    if (openUi) {
        sendKeybind()
        Sleep, 50
        if (UINavigationFix) {
            repeatKey("Up", 5, 50)
            Sleep, 50
            repeatKey("Left", 3, 50)
            Sleep, 50
            repeatKey("up", 5, 50)
            Sleep, 50
            repeatKey("Left", 3, 50)
            Sleep, 50
        }   
    }  

    ; right = R, left = L, up = U, down = D, enter = 0, manual delay = 5
    if (mode = "universal") {

        Loop, Parse, order 
        {
            if (A_LoopField = "R") {
                repeatKey("Right", 1)
            }
            else if (A_LoopField = "L") {
                repeatKey("Left", 1)
            }
            else if (A_LoopField = "U") {
                repeatKey("Up", 1)
            }        
            else if (A_LoopField = "D") {
                repeatKey("Down", 1)
            }  
            else if (A_LoopField = "0") {
                repeatKey("Enter", spam ? spamCount : 1, spam ? 10 : 0)
            }       
            else if (A_LoopField = "5") {
                Sleep, 100
            } 
            if (SavedSpeed = "Stable" && A_LoopField != "5") {
                Sleep, %delayTime%
            }
        }

    }
    ; else if (mode = "calculate") {
    ; }
    else if (mode = "close") {

        if (dir = "up") {
            repeatKey(dir)
            repeatKey("Enter")
            repeatKey(dir, index)
        }
        else if (dir = "down") {
            repeatKey(dir, index)
            repeatKey("Enter")
            repeatKey(dir)
        }

    }

    if (exitUi) {
        Sleep, 50
        sendKeybind()
    }

    return

}
