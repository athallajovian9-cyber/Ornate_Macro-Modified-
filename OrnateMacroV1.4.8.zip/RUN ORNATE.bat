@echo off
title Ornate Macro  (AutoHotkey v1.1)
cd /d "%~dp0OrnateMacroV1.4.8"
set "ENGINE=C:\Program Files\AutoHotkey\v1.1.37.02\AutoHotkeyU64.exe"
if not exist "%ENGINE%" (
    echo AutoHotkey v1.1 was not found at:
    echo   %ENGINE%
    echo Install AutoHotkey v1.1, or edit ENGINE in this file.
    pause
    exit /b 1
)
echo Starting Ornate with the v1.1 engine...
start "" "%ENGINE%" "Ornate.ahk"
exit /b 0
