#Requires AutoHotkey v1.1
#NoTrayIcon
#Persistent
#SingleInstance Force
CoordMode, Pixel, Window
CoordMode, Mouse, Window
#Include %A_ScriptDir%\helpers.ahk
global navigationDelay := A_Args.Length() >= 2 ? A_Args[2] : 300

NavigationSleep() {
    global navigationDelay
    Sleep, %navigationDelay%
}

SendMode, Event

if (A_Args.Length() >= 1) {
    digspeed := A_Args[1]
} else {
    digspeed := 123
}

; === MAIN HERE ===
Send, {w up}{a up}{s up}{d up}{LButton up}{Space up}{Left up}{Right up}
HotbarMove()
Send, {d down}
Sleep, 900
Send, {d up}
Send, {s down}
Sleep, 3300
Send, {s up}
Send, {a down}
Sleep, 600
Send, {a up}
Send, {e down}
Sleep, 100
Send, {e up}
Sleep, 100
Send, {w}
Sleep, 100
InfernalHeartTP()
Sleep, 50
HotbarMove()
NavigationSleep()
Send, {1}
Send, {w down}{a down}
Sleep, 2500
Send, {w up}{a up}
Sleep, 30
Send, {Right down}
Sleep 255
Send, {Right up}
Sleep, 30
Send, {w down}
Sleep 12000
Send, {w up}
Sleep, 30
Send, {Left down}
Sleep 100
Send, {Left up}
Sleep, 30
Send, {w down}
Sleep 3100
Send, {w up}
Sleep, 30
Send, {Left down}
Sleep 550
Send, {Left up}
Sleep, 30
Send, {w down}
Sleep 4200
Send, {w up}
Sleep, 30
Send, {Right down}
Sleep 1320
Send, {Right up}

; ===============


ExitApp  ; terminate script11 cleanly






