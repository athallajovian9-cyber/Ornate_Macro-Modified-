global LOCAL_VERSION := "1.4.8"
global VERSION_URL   := "https://pastebin.com/raw/XuDwFBsV"

CheckForUpdate(showIfCurrent := false) {
    remote := Trim(HttpGet(VERSION_URL, 5000))  
    if (!remote) {
        return   
    }     
    RegExMatch(remote, "O)\d+(\.\d+){0,3}", m)
    if (!m)
        return
    latest := m.Value(0)
    cmp := VersionCompare(LOCAL_VERSION, latest)
    if (cmp < 0) {
        MsgBox, 48, Update Available, 
        (LTrim
        This version (%LOCAL_VERSION%) is OUTDATED.  
        Latest: %latest%   

        Please download the newest build from our Discord at discord.gg/ornate.
        )  
    } else if (showIfCurrent) {
        TrayTip, Ornate Macro, You’re up to date (%LOCAL_VERSION%)., 2, 1
    }    
}
 
HttpGet(url, timeoutMs := 5000) {
    try {
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", url, false)
        whr.SetTimeouts(timeoutMs, timeoutMs, timeoutMs, timeoutMs)
        whr.SetRequestHeader("User-Agent", "OrnateMacro-Updater/1.0")
        whr.Send()
        if (whr.Status = 200)
            return whr.ResponseText
    }
    catch e {
    }
    return ""
}

VersionCompare(a, b) {
    aParts := StrSplit(a, ".")
    bParts := StrSplit(b, ".")
    maxN := (aParts.MaxIndex() > bParts.MaxIndex()) ? aParts.MaxIndex() : bParts.MaxIndex()
    Loop, %maxN% {
        ai := aParts[A_Index] + 0
        bi := bParts[A_Index] + 0
        if (ai < bi)
            return -1
        else if (ai > bi)
            return 1
    }
    return 0

}


