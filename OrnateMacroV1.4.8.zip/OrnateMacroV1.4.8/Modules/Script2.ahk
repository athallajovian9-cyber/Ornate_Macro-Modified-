#Requires AutoHotkey v1.1
#NoTrayIcon
#Persistent
#SingleInstance Force
CoordMode, Pixel, Window
CoordMode, Mouse, Window
#Include %A_ScriptDir%\helpers.ahk

SendMode, Event

if (A_Args.Length() >= 1) {
    digspeed := A_Args[1]
} else {
    digspeed := 123
}

; === MAIN HERE ===
Send, {w up}{a up}{s up}{d up}{LButton up}{Space up}{Left up}{Right up}
HotbarMove()
Sleep, 250
Send, {1}
Sleep, 30
Send, {s down}
Sleep, 300
Send, {s up}
Sleep, 30
Send, {a down}
Sleep, 8700
Send, {a up}
Sleep, 30
Send, {right down}
Sleep, 700
Send, {right up}



ExitApp  ; terminate script1 cleanly




