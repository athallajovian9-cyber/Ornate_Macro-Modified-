#Requires AutoHotkey v1.1
; Ornate Macro (discord.gg/Ornate)
; Please do not steal our code
; Copyright © ORNATE MACRO (PROSPECTING!)
#NoEnv
#Persistent
#SingleInstance Force
SetWorkingDir %A_ScriptDir%
#InstallKeybdHook
#UseHook
#MaxThreadsPerHotkey 2
#MaxThreads 255
#HotkeyInterval 100
#MaxHotkeysPerInterval 200
#HotkeyModifierTimeout 1000
#Include %A_ScriptDir%\helpers.ahk
#Include %A_ScriptDir%\CurrentVersion.ahk

SendMode, Event


; ===== UTC Void Scheduler (AHK v1.1) =====
; Event windows are anchored to pure UTC.
; Active windows: [HH:05 .. HH:35) at UTC hours {00,03,06,09,12,15,18,21}.

; PUBLIC HELPERS:
; IsWithinVoidWindowUTC()
; GetMsUntilNextVoidStart()
GetNextUTCWindow(ByRef startUTC, ByRef endUTC)

IsWithinVoidWindowUTC() {
    utcNow := GetUtcNowStamp()
    GetNextUTCWindow(curStart, curEnd, utcNow, true)  ; allow current
    return (curStart != "" && curEnd != "" && utcNow >= curStart && utcNow < curEnd)
}

GetMsUntilNextVoidStart() {
    utcNow := GetUtcNowStamp()
    GetNextUTCWindow(nextStart, nextEnd, utcNow, false)
    if (nextStart = "")
        return 60000
    return TimeDiffMs(nextStart, utcNow)
}

GetNextUTCWindow(ByRef outStartUTC, ByRef outEndUTC, utcNow := "", allowCurrent := false) {
    outStartUTC := "", outEndUTC := ""
    if (utcNow = "")
        utcNow := GetUtcNowStamp()

    ; Build candidate windows for today and tomorrow (UTC), then pick the earliest valid.
    allowed := [0,3,6,9,12,15,18,21]
    bestStart := "", bestEnd := ""

    Loop, 2 {
        dayUTC := utcNow
        if (A_Index = 2)
            EnvAdd, dayUTC, 1, Days
        ymd := SubStr(dayUTC, 1, 8)  ; YYYYMMDD

        for idx, hh in allowed {
            startUTC := BuildStamp(ymd, hh, 05, 00)
            endUTC   := BuildStamp(ymd, hh, 35, 00)

            if (allowCurrent && utcNow >= startUTC && utcNow < endUTC) {
                outStartUTC := startUTC, outEndUTC := endUTC
                return
            }
            if (utcNow < startUTC) {
                if (bestStart = "" || startUTC < bestStart)
                    bestStart := startUTC, bestEnd := endUTC
            }
        }
    }
    outStartUTC := bestStart, outEndUTC := endEnd
}

; ---------- Robust UTC helpers ----------
GetUtcNowStamp() {
    ; Prefer A_NowUTC if present; otherwise compute from local using Windows timezone info.
    utc := A_NowUTC
    if (StrLen(utc) = 14)  ; looks valid
        return utc

    ; Fallback: UTC = local + totalBiasMinutes
    local := A_Now
    bias := GetLocalUtcBiasMinutes()  ; e.g., 360 for CST, 300 for CDT, 0 for UTC
    EnvAdd, local, %bias%, Minutes
    return local
}

GetLocalUtcBiasMinutes() {
    ; Uses GetTimeZoneInformation to compute bias to add to local to get UTC.
    VarSetCapacity(TZI, 172, 0) ; TIME_ZONE_INFORMATION
    res := DllCall("GetTimeZoneInformation", "Ptr", &TZI, "Int")
    baseBias := NumGet(TZI, 0, "Int")
    stdBias  := NumGet(TZI, 148, "Int")
    dltBias  := NumGet(TZI, 168, "Int")
    if (dltBias = 0 && (A_PtrSize=4))
        dltBias := NumGet(TZI, 164, "Int")

    if (res = 2) { ; TIME_ZONE_ID_DAYLIGHT
        total := baseBias + dltBias
    } else {
        total := baseBias + stdBias
    }
    return total
}

; ---------- Date helpers ----------
BuildStamp(ymd, hh, mm, ss) {
    return Format("{:8s}{:02}{:02}{:02}", ymd, hh, mm, ss)
}

TimeDiffMs(futureStamp, nowStamp) {
    t1 := nowStamp, t2 := futureStamp
    EnvSub, t2, %t1%, Seconds
    return t2 * 1000
}
; ===== End UTC Void Scheduler =====



; === Globals ===
; === VOID TIMING CONFIG (Easy toggle) ===
; Set to 1 to TEST: Void is allowed EVERY HOUR between the minute window below.
; Set to 0 to revert to ORIGINAL: Void allowed ONLY at UTC hours 00,03,06,09,12,15,18,21 within the same minute window.
global VOID_TEST_HOURLY := 0
; Keep the same minute window you had before (05–27). Change if needed.
global VOID_WINDOW_START_MIN_UTC := 5   ; inclusive
global VOID_WINDOW_END_MIN_UTC   := 34  ; exclusive
global navigationDelay := A_Args.Length() >= 2 ? A_Args[2] : 300

; NAV NAV NAV
NavigationSleep() {
    global navigationDelay
    Sleep, %navigationDelay%
}

; === Globals ===
global TooltipMap := {}
global MainLoadout, SellLoadout  ; new super cool global for loadout switching yipe kai yeah!
global settingsFile := A_ScriptDir . "\OrnateMacro_Settings.ini"
if !FileExist(settingsFile)
{
    FileAppend,, %settingsFile%  ; Create empty ini if it doesn't exist
}
global running := false
global paused := false
global mainStopped := true
global EnableInstantSell := 0
global spamActive := 0

; Delays
global DigspeedInput := 123
global ResetDelay := 13
global MerchantDelay := 5
global baseHoldTime := 570
global holdTime := baseHoldTime
global DiggingFallbackDelay := 30
global PanningFallbackDelay := 30
global NavigationDelaySecs := 0.3

; Buff Counters & Timers
global luckTotemsRemaining := 0
global strengthTotemsRemaining := 0
global luckTotemsOwned := 0
global strengthTotemsOwned := 0
global merchantsPotionsRemaining := 0
global autoSellCounter := 0
global lastLuckTotemPlacementTime := 0
global lastStrengthTotemPlacementTime := 0
global totemCooldown := 32 * 60 * 1000 ; Set totem cooldown to 32 minutes

; PIDs
global runningScriptPID := 0
global mainAhkPID := 0
global runningScriptPIDs := []

; Image & Auto-Sell Logic
global fullImage := "pan_full.png"
global emptyImage := "pan_empty.png"
global panEmptyLImage := "pan_empty_L.png"
global panEmptyStartTime := 0
global sellCycleCausedReset := false

; === Globals for Timed Area Rotation ===
global areaEnabled1, areaEnabled2, areaEnabled3
global areaSelection1, areaSelection2, areaSelection3
global activeAreaSelection1, activeAreaSelection2, activeAreaSelection3 ; State-tracking variables
global areaPausedTime1 := 0, areaPausedTime2 := 0, areaPausedTime3 := 0
global totalEnabledAreas := 0
global currentAreaIndex := 1
global currentAreaStartTime := 0
global hasSwitchedToIH := false
global previousIHRange := "uninitialized" ; *** NEW: For IHD logic
global TimedEventPriority := "VOID" ; Can be "INFERNAL HEART" or "VOID"

; === Globals for Custom Location State ===
global EnableCustomLocation := 0

; === Globals for Hotkeys ===
global StartHotkey := "F6"
global StopHotkey := "F8"
global OldStartHotkey := "F6"
global OldStopHotkey := "F8"

; === Script Labels and Colors ===
global scriptLabels := ["RUBBLE CREEK SANDS", "RUBBLE CREEK DEPOSITS", "FORTUNE RIVER", "SUNSET BEACH", "FORTUNE RIVER DELTA", "CRYSTAL CAVERNS", "AZURALITE OASIS", "VOLCANIC SANDS", "WINDSWEPT BEACH", "THE MAGMA FURNACE", "THE INFERNAL HEART", "FROSTBITE RIVER", "FROSTBITE WATERFALL", "FROZEN PEAK", "VOID", "OVERGROWN GOTTO", "DEEPROOT SPRING", "HAUNTED CREEK", "ROTWOOD SWAMP", "FUNGAL MARCH"]
global colors := ["C2B280", "89CFF0", "D87093", "FFDAB9", "8DB600", "00FFFF", "00CED1", "B22222", "DEB887", "FF0000", "DC143C", "ADD8E6", "E0FFFF", "F0F8FF", "800080", "50C878", "20B2AA", "20B2AA", "20B2AA"]

; === GUI Setup ===
Gui, +AlwaysOnTop -SysMenu +MinimizeBox +Resize
Gui, Color, 252525
Gui, Font, s10 cE0E0E0, Segoe UI
Gui, Font, s14 Bold
Gui, Add, Text, x15 y15 cffdd00, Ornate Macro V%LOCAL_VERSION%
Gui, Font, s11 Bold
Gui, Add, Tab3, x10 y45 w480 h680 vMainTab, Locations|Buffs|Sell Logic|Delays|Hotkeys|Credits 

; --- Locations Tab ---
Gui, Tab, Locations
Gui, Font, s10 Norm cAAAAAA, Segoe UI ; Changed text color to grey as requested
Gui, Add, Text, x20 y80, Configure up to 3 grinding locations and their rotation schedule.
Gui, Add, Text, x20 y100 w460, The macro cycles through enabled slots.
Gui, Add, Text, x20 y120 w460, If only one is enabled, it grinds there indefinitely.
Gui, Font, s10 Bold c00A0E0 ; Revert to original tab color
Gui, Add, GroupBox, x20 y145 w460 h55, Timed Event Priority
Gui, Font, s9 Norm
Gui, Font, cFF4500 ; Red-Orange for Infernal Heart
Gui, Add, Radio, vPriorityIH Group x35 y170, Infernal Heart
Gui, Font, cBF00FF ; Neon Purple for Void
; *** MODIFIED: Added g-label to the Void radio button to handle clicks ***
Gui, Add, Radio, vPriorityVoid x250 y170 gOnPriorityVoidSelect, Void
Gui, Font, c00A0E0 ; Reset to original tab color

locationList := ""
Loop, % scriptLabels.MaxIndex() {
    label := scriptLabels[A_Index]
    locationList .= label . "|"
}
StringTrimRight, locationList, locationList, 1
Gui, Font, s10 Bold
Gui, Add, GroupBox, x20 y210 w460 h90, Slot 1
Gui, Add, CheckBox, vAreaEnabled1 gUpdateAreaState x35 y235 w120, Enable Slot 1
Gui, Font, s9 Norm
Gui, Add, Text, x35 y270, Location:
Gui, Add, DropDownList, vAreaSelection1 gOnLocationChange x105 y267 w200, %locationList%
Gui, Add, Text, x325 y270, Duration (min):
Gui, Add, Edit, vAreaDuration1 x420 y267 w50 +Number +Center c000000, 60
Gui, Font, s10 Bold
Gui, Add, GroupBox, x20 y310 w460 h90, Slot 2
Gui, Add, CheckBox, vAreaEnabled2 gUpdateAreaState x35 y335 w120, Enable Slot 2
Gui, Font, s9 Norm
Gui, Add, Text, x35 y370, Location:
Gui, Add, DropDownList, vAreaSelection2 gOnLocationChange x105 y367 w200, %locationList%
Gui, Add, Text, x325 y370, Duration (min):
Gui, Add, Edit, vAreaDuration2 x420 y367 w50 +Number +Center c000000, 60
Gui, Font, s10 Bold
Gui, Add, GroupBox, x20 y410 w460 h90, Slot 3
Gui, Add, CheckBox, vAreaEnabled3 gUpdateAreaState x35 y435 w120, Enable Slot 3
Gui, Font, s9 Norm
Gui, Add, Text, x35 y470, Location:
Gui, Add, DropDownList, vAreaSelection3 gOnLocationChange x105 y467 w200, %locationList%
Gui, Add, Text, x325 y470, Duration (min):
Gui, Add, Edit, vAreaDuration3 x420 y467 w50 +Number +Center c000000, 60

; --- Custom Location GUI ---
Gui, Font, s10 Bold
Gui, Add, GroupBox, x20 y510 w460 h100, Custom Location
Gui, Add, CheckBox, x35 y535 w200 h25 vEnableCustomLocation gToggleCustomLocation, Custom-Location Disabled
GuiControl, +c8B0000, EnableCustomLocation
Gui, Font, s9 Norm cAAAAAA
Gui, Add, Text, x35 y570 w430 +Wrap, Custom-Location Farming allows you to farm anywhere you want, but it will neither auto-sell nor get you to your destinations. Fallbacks are also disabled.

; --- Buffs Tab ---
Gui, Tab, Buffs
Gui, Font, s9 Bold
Gui, Add, Text, x250 y85 cFFD700, (Costs 50K coins per potion)
Gui, Add, GroupBox, x30 y100 w440 h120 cAAAAAA, Basic Potions
Gui, Font, s9
Gui, Add, Checkbox, x50 y125 w120 h25 vRenewLuck gToggleRenewLuck c228B22 BackgroundTrans, Basic Luck
Gui, Add, Edit, x180 y125 w45 h25 vLuckPotions gUpdateLuckPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y125 w210 h25 vLuckDurationText cAAAAAA, You will have 0 hours of Luck.
Gui, Add, Checkbox, x50 y165 w120 h25 vRenewCapacity gToggleRenewCapacity cCD853F BackgroundTrans, Basic Capacity
Gui, Add, Edit, x180 y165 w45 h25 vCapacityPotions gUpdateCapacityPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y165 w210 h25 vCapacityDurationText cAAAAAA, You will have 0 hours of Capacity.
Gui, Font, s9 Bold
Gui, Add, Text, x240 y225 cFFD700, (Costs 30-20 Shards per potion)
Gui, Add, GroupBox, x30 y240 w440 h120 cAAAAAA, Greater Potions
Gui, Font, s9
Gui, Add, Checkbox, x50 y265 w120 h25 vRenewGreaterLuck gToggleRenewGreaterLuck c32CD32 BackgroundTrans, Greater Luck
Gui, Add, Edit, x180 y265 w45 h25 vGreaterLuckPotions gUpdateGreaterLuckPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y265 w220 h33 vGreaterLuckDurationText cAAAAAA, You will have 0.00 hours of Greater Luck.
Gui, Add, Checkbox, x50 y305 w120 h25 vRenewGreaterCapacity gToggleRenewGreaterCapacity cFFA500 BackgroundTrans, Greater Capacity
Gui, Add, Edit, x180 y305 w45 h25 vGreaterCapacityPotions gUpdateGreaterCapacityPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y305 w220 h33 vGreaterCapacityDurationText cAAAAAA, You will have 0.00 hours of Greater Capacity.
Gui, Font, s9 Bold
Gui, Add, Text, x230 y365 cFFD700, (Costs 300-180-200 Shards per item)
Gui, Add, GroupBox, x30 y380 w440 h150 cAAAAAA, Totems & Misc
Gui, Font, s9
Gui, Add, Checkbox, x50 y405 w120 h25 vRenewLuckTotem gToggleRenewLuckTotem c6B8E23 BackgroundTrans, Luck Totems
Gui, Add, Edit, x180 y405 w45 h25 vLuckTotemCount Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y408, Owned:
Gui, Add, Edit, vLuckTotemOwned x285 y405 w45 h25 Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Checkbox, x50 y445 w120 h25 vRenewStrengthTotem gToggleRenewStrengthTotem cFF7F50 BackgroundTrans, Strength Totems
Gui, Add, Edit, x180 y445 w45 h25 vStrengthTotemCount Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y448, Owned:
Gui, Add, Edit, vStrengthTotemOwned x285 y445 w45 h25 Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Checkbox, x50 y485 w120 h25 vRenewMerchantsPotion gToggleRenewMerchantsPotion cFFFF00 BackgroundTrans, Merchant's Potion
Gui, Add, Edit, x180 y485 w45 h25 vMerchantsPotionCount Disabled c000000 BackgroundWhite +Number, 0

; --- Volcanic Buffs Tab ---
Gui, Font, s9 Bold
Gui, Add, Text, x190 y535 cFFD700, (Costs 1M Coins -1M Coins - 120 Shards per item)
Gui, Add, GroupBox, x30 y550 w440 h150 cAAAAAA, Volcanic Buffs
Gui, Font, s9
Gui, Add, Checkbox, x50 y575 w120 h25 vRenewVolcanicLuck gToggleRenewVolcanicLuck c8AE600 BackgroundTrans, Volcanic Luck
Gui, Add, Edit, x180 y575 w45 h25 vVolcanicLuckPotionCount gUpdateVolcanicLuckPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y575 w220 h33 vVolcanicLuckDurationText cAAAAAA, You will have 0.00 hours of Volcanic Luck.
Gui, Add, Checkbox, x50 y615 w120 h25 vRenewVolcanicStrength gToggleRenewVolcanicStrength cFF6700 BackgroundTrans, Volcanic Strength
Gui, Add, Edit, x180 y615 w45 h25 vVolcanicStrengthPotionCount gUpdateVolcanicStrengthPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y615 w220 h33 vVolcanicStrengthDurationText cAAAAAA, You will have 0.00 hours of Volcanic Strength.
Gui, Add, Checkbox, x50 y655 w120 h25 vRenewSupremeLuck gToggleRenewSupremeLuck cBF00FF BackgroundTrans, Supreme Luck
Gui, Add, Edit, x180 y655 w45 h25 vSupremeLuckPotionCount gUpdateSupremeLuckPotions Disabled c000000 BackgroundWhite +Number, 0
Gui, Add, Text, x235 y655 w220 h33 vSupremeLuckDurationText cAAAAAA, You will have 0.00 hours of Supreme Luck.
; --- Sell Logic Tab ---
Gui, Tab, Sell Logic
Gui, Font, s10 Bold
Gui, Add, Checkbox, x40 y92 w220 h25 vEnableAutoSell gToggleAutoSell, Merchant-Auto-Sell Disabled
GuiControl, +c8B0000, EnableAutoSell
Gui, Add, Checkbox, x40 y122 w220 h25 vEnableInstantSell gToggleInstantSell, Instant-Sell-Gamepass Disabled
GuiControl, +c8B0000, EnableInstantSell

; === NEW: Loadout Switcher Toggle ===
Gui, Add, Checkbox, x40 y160 w220 h25 vEnableLoadoutSwitcher gToggleLoadoutSwitcher, Enable Loadout Switching
GuiControl, +c8B0000, EnableLoadoutSwitcher

; === Loadout Switcher (Moved and Adjusted) ===
Gui, Font, s10 Bold
Gui, Add, GroupBox, x40 y190 w420 h100, Loadout Switcher
Gui, Font, s9 Norm cF0F0F0
Gui, Add, Text, x55 y220, Main/Grinding Loadout:
Gui, Add, DropDownList, vMainLoadout x215 y217 w150, Loadout 1|Loadout 2|Loadout 3
Gui, Add, Text, x55 y250, Sell Loadout:
Gui, Add, DropDownList, vSellLoadout x215 y247 w150, Loadout 1|Loadout 2|Loadout 3

; === Updated Disclaimer (Adjusted y-coordinate) ===
Gui, Font, s12 Bold cFF0000
Gui, Add, Text, x40 y300, DISCLAIMER
Gui, Font, s10 Norm cF0F0F0
Gui, Add, Text, x40 y320 w420 +Wrap, For the loadout switcher to work correctly, you must have exactly three total loadouts. The loadout switcher only switches when it needs to sell.

; --- Delays Tab ---
Gui, Tab, Delays
Gui, Font, s9 Bold
Gui, Add, GroupBox, x30 y80 w440 h70, Digging Delay
Gui, Font, s9
Gui, Add, Text, x50 y105 cF0F0F0, Dig Speed `% (from stats):
Gui, Add, Edit, vDigspeedInput w100 x210 y102 +Number c000000, %DigspeedInput%

Gui, Font, s9 Bold
Gui, Add, GroupBox, x30 y160 w440 h90, Character Reset Delay
Gui, Font, s9
Gui, Add, Text, x50 y190 cF0F0F0, Delay after character reset (in seconds).
Gui, Add, Text, x50 y210 cFFA500, Recommended: 13
Gui, Add, Edit, vResetDelay w100 x210 y207 +Number c000000, %ResetDelay%

Gui, Font, s9 Bold
Gui, Add, GroupBox, x30 y260 w440 h90, Merchant Sell Delay
Gui, Font, s9
Gui, Add, Text, x50 y290 cF0F0F0, Delay after selling items at the merchant (in seconds).
Gui, Add, Text, x50 y310 cFFA500, Recommended: 5
Gui, Add, Edit, vMerchantDelay w100 x210 y307 +Number c000000, %MerchantDelay%

Gui, Font, s9 Bold
Gui, Add, GroupBox, x30 y360 w440 h90, Digging Fallback Delay
Gui, Font, s9
Gui, Add, Text, x50 y390 cF0F0F0, Time until Digging Fallback triggers (in seconds).
Gui, Add, Text, x50 y410 cFFA500, Recommended: 30
Gui, Add, Edit, vDiggingFallbackDelay w100 x210 y407 +Number c000000, %DiggingFallbackDelay%

Gui, Font, s9 Bold
Gui, Add, GroupBox, x30 y460 w440 h90, Panning Fallback Delay
Gui, Font, s9
Gui, Add, Text, x50 y490 cF0F0F0, Time until Panning Fallback triggers (in seconds).
Gui, Add, Text, x50 y510 cFFA500, Recommended: 30
Gui, Add, Edit, vPanningFallbackDelay w100 x210 y507 +Number c000000, %PanningFallbackDelay%

Gui, Font, s9 Bold
Gui, Add, GroupBox, x30 y560 w440 h90, Navigation Delay
Gui, Font, s9
Gui, Add, Text, x50 y590 cF0F0F0, Delay after teleporting (in seconds).
Gui, Add, Text, x50 y610 cFFA500, Recommended: 0.3
Gui, Add, Edit, vNavigationDelaySecs w100 x210 y607 +Number c000000, %NavigationDelaySecs%

; --- Hotkeys Tab ---
Gui, Tab, Hotkeys
Gui, Font, s10 Norm cAAAAAA
Gui, Add, Text, x30 y90, Set your custom hotkeys for starting and stopping the macro.
Gui, Add, Text, x30 y110, Click in the box and press your desired key.
Gui, Font, s10 Bold
Gui, Add, GroupBox, x20 y140 w460 h150, Macro Hotkeys
Gui, Font, s9 Norm
Gui, Add, Text, x50 y175, Start/Resume Macro:
Gui, Add, Hotkey, vStartHotkey x200 y172 w100
Gui, Add, Text, x50 y210, Stop Macro:
Gui, Add, Hotkey, vStopHotkey x200 y207 w100
; --- Credits Tab ---
Gui, Tab, Credits
left_x := 20
right_x := 255
col_w := 227
Gui, Font, s10 Bold cE0E0E0
Gui, Add, GroupBox, x%left_x% y70 w%col_w% h570, Development
Gui, Font, s8 Norm cAAAAAA
Gui, Add, Text, x30 y95 w200, Special Thanks to the developers, staff, and testers!
; --- Start of MODIFIED Development/Staff/Testers Section ---
x_pos_1 := 40
x_pos_2 := 140
y_pos := 145

; --- Developers Section (Golden) ---
Gui, Font, s10 Bold cE5B35E
Gui, Add, Text, x35 y%y_pos%, Developers
y_pos += 25
Gui, Font, s9 Norm cE5B35E ; Golden for developer names
Gui, Add, Text, x%x_pos_1% y%y_pos%, boguscr4cker
Gui, Add, Text, x%x_pos_2% y%y_pos%, loyabbobster
y_pos += 20
Gui, Add, Text, x%x_pos_1% y%y_pos%, coralmao

; --- Staff Section (Blue) ---
y_pos += 40
Gui, Font, s10 Bold cE5B35E
Gui, Add, Text, x35 y%y_pos%, Staff
y_pos += 25
Gui, Font, s9 Norm c0073FF ; Blue for staff names

; --- Row 1 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, celx
Gui, Add, Text, x%x_pos_2% y%y_pos%, raven
y_pos += 20

; --- Row 2 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, nre_so
Gui, Add, Text, x%x_pos_2% y%y_pos%, Kyle
y_pos += 20

; --- Row 3 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, da d guy
Gui, Add, Text, x%x_pos_2% y%y_pos%, nre_so
y_pos += 20

; --- Row 4 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, BigEasy
Gui, Add, Text, x%x_pos_2% y%y_pos%, Landon
y_pos += 20

; --- Row 5 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, monke
Gui, Add, Text, x%x_pos_2% y%y_pos%, exho.tek
y_pos += 20

; --- Row 6 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, RJ
Gui, Add, Text, x%x_pos_2% y%y_pos%, RON
y_pos += 20

; --- Row 7 ---
Gui, Add, Text, x%x_pos_1% y%y_pos%, veyuki
Gui, Add, Text, x%x_pos_2% y%y_pos%, Verkan

; --- Testers Section (Green) ---
y_pos += 40
Gui, Font, s10 Bold cE5B35E
Gui, Add, Text, x35 y%y_pos%, Testers
y_pos += 25
Gui, Font, s9 Norm c2ECC71 ; Green for tester names
Gui, Add, Text, x%x_pos_1% y%y_pos%, nre_siak
Gui, Add, Text, x%x_pos_2% y%y_pos%, catbosforever
y_pos += 20
Gui, Add, Text, x%x_pos_1% y%y_pos%, Vironium
Gui, Add, Text, x%x_pos_2% y%y_pos%, Chickensandwich_1
y_pos += 20
Gui, Add, Text, x%x_pos_1% y%y_pos%, chaosisbetter
Gui, Add, Text, x%x_pos_2% y%y_pos%, tox1city
y_pos += 20
Gui, Add, Text, x%x_pos_1% y%y_pos%, bszpta
Gui, Add, Text, x%x_pos_2% y%y_pos%, TONYP7494
; --- End of MODIFIED Section ---

; --- Special Thanks Section (HOT Pink) ---
y_pos += 40
Gui, Font, s10 Bold cFF0073
Gui, Add, Text, x35 y%y_pos%, Code Contributer
y_pos += 25
Gui, Font, s9 Norm cF5FFA6
Gui, Add, Text, x%x_pos_1% y%y_pos%, tropicalwave101 has contributed
y_pos += 20
Gui, Font, s9 Norm cFFF4C9
Gui, Add, Text, x%x_pos_1% y%y_pos%, a lot with the code. He helped
y_pos += 20
Gui, Font, s9 Norm cFFF4C9
Gui, Add, Text, x%x_pos_1% y%y_pos%, add features and bug fixed the others.
; --- Supporters GUI Code ---
Gui, Font, s10 Bold cE0E0E0
Gui, Add, GroupBox, x%right_x% y70 w%col_w% h775, Supporters

; --- Start of Supporters Section ---
sup_x_pos_1 := right_x + 15
sup_x_pos_2 := right_x + 115
sup_y_pos := 95

Gui, Font, s9 Bold c2ECC71 ; Green and Bold for supporter names

; --- Row 1 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, grim00
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, chroma
sup_y_pos += 20

; --- Row 2 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, pottsy1985
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, highonfudges
sup_y_pos += 20

; --- Row 3 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, _skiver
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, aemiroo
sup_y_pos += 20

; --- Row 4 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, poststages
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, mnxh
sup_y_pos += 20

; --- Row 5 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, benni6196
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, mcelx
sup_y_pos += 20

; --- Row 6 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, ceraise
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, cookie777
sup_y_pos += 20

; --- Row 7 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, pvtcuddles
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, wiki.js
sup_y_pos += 20

; --- Row 8 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, devhatter
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, pro_cat
sup_y_pos += 20

; --- Row 9 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, Enercakq
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, 1evo1
sup_y_pos += 20

; --- Row 10 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, frd_zzzz
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, holyfinesse
sup_y_pos += 20

; --- Row 11 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, gerfreezer
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, hongx99
sup_y_pos += 20

; --- Row 12 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, ht_qe
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, zlxp
sup_y_pos += 20

; --- Row 13 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, jack1_oo
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, jasca22
sup_y_pos += 20

; --- Row 14 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, ethay
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, scripteases
sup_y_pos += 20

; --- Row 15 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, keyboardmydude
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, kollyrelp
sup_y_pos += 20

; --- Row 16 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, kubs0n3k
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, LapokSeiji
sup_y_pos += 20

; --- Row 17 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, Lenny
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, kot420
sup_y_pos += 20

; --- Row 18 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, marcezek2450
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, wwwenporsche
sup_y_pos += 20

; --- Row 19 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, nass14
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, akil
sup_y_pos += 20

; --- Row 20 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, nonethel_ss
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, olihver
sup_y_pos += 20

; --- Row 21 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, paimonmy
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, filthygamer88
sup_y_pos += 20

; --- Row 22 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, prohracsvk
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, katpescarul
sup_y_pos += 20

; --- Row 23 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, raven097__
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, rufus
sup_y_pos += 20

; --- Row 24 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, switchlevel1
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, trickeydd
sup_y_pos += 20

; --- Row 25 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, thelolgod
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, thermoa
sup_y_pos += 20

; --- Row 26 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, thouy
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, tonyp
sup_y_pos += 20

; --- Row 27 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, victim
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, w0llfie
sup_y_pos += 20

; --- Row 28 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, swopyn
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, Ron
sup_y_pos += 20


; --- Row 29 ---
Gui, Add, Text, x%sup_x_pos_1% y%sup_y_pos%, Tehh
Gui, Add, Text, x%sup_x_pos_2% y%sup_y_pos%, iDev4You


; --- End of Supporters Section ---


; --- Bottom Bar ---
Gui, Tab
Gui, Font, s9 c999999
Gui, Add, Text, x20 y725 vStartKeyText, %StartHotkey% to Start & Hide Ornate
Gui, Add, Text, x178 y725, |
Gui, Add, Text, x190 y725 vStopKeyText, %StopHotkey% to Stop Ornate
Gui, Add, Button, gSaveChanges x350 y730 w120 h30, Save Changes

; === Donate Link ===
global paypal_link := "https://paypal.me/OrnateMacro"

; Add a clean, clickable "Donate via PayPal" link.
Gui, Font, s10 Bold c89CFF0 underline
Gui, Add, Text, x20 y750 w200 gOpenPayPal, Donate via PayPal
Gui, Font, norm ; Reset the font back to default

LoadSettings()

; --- Run startup GUI updates for Buffs Tab BEFORE showing the GUI ---
GoSub, ToggleRenewLuck
GoSub, ToggleRenewCapacity
GoSub, ToggleRenewGreaterLuck
GoSub, ToggleRenewGreaterCapacity
GoSub, ToggleRenewLuckTotem
GoSub, ToggleRenewStrengthTotem
GoSub, ToggleRenewMerchantsPotion
GoSub, ToggleRenewVolcanicLuck
GoSub, ToggleRenewVolcanicStrength
GoSub, ToggleRenewSupremeLuck

OnMessage(0x200, "WM_MOUSEMOVE")
Gui, Show, w500 h775, Ornate Macro ; Adjusted height
; *** ADDED: Flag to temporarily block the WM_MOUSEMOVE tooltip clearing ***
global blockTooltipClear := false
return

OpenKoFi:
    ; FIXED: this ran %link%, which is assigned NOWHERE in the project, so the
    ; Ko-fi button did nothing at all and gave no feedback. The author has a
    ; paypal_link global but never created the matching Ko-fi one. Rather than
    ; invent a URL, fail visibly so the omission is obvious.
    if (link != "")
        Run, %link%
    else
        MsgBox, 64, Ornate Macro, The Ko-fi link is not set in this build.`n`nSet the link global next to paypal_link to enable it.
return

OpenPayPal:
    Run, %paypal_link%
return

WM_MOUSEMOVE() {
    static LastHwnd
    global TooltipMap, blockTooltipClear

    ; *** MODIFIED: Check flag before clearing tooltips ***
    if (blockTooltipClear)
        return

    MouseGetPos, , , hwnd
    
    if (hwnd = LastHwnd)
        return
    
    LastHwnd := hwnd
    ToolTip

    GuiControlGet, ctrlVar, Name, %hwnd%
    if (ctrlVar = "")
        return

    if (TooltipMap.HasKey(ctrlVar)) {
        ToolTip, % TooltipMap[ctrlVar]
        SetTimer, RemoveToolTip, -3000
    }
}

CheckStop() {
    global running
    if (!running) {
        throw "MacroStopped"
    }
}

UpdateAreaState:
    GoSub, UpdateLocationControls
return

ToggleCustomLocation:
    Gui, Submit, NoHide
    global TooltipMap
    
    custom_tooltip_text := "Disable 'Custom-Location' to configure locations and selling."
    timed_event_tooltip_text := "Disable 'Custom-Location' to configure timed events."
    if (EnableCustomLocation) {
        GuiControl, +c32CD32, EnableCustomLocation
        GuiControl,, EnableCustomLocation, Custom-Location Enabled

        ; Disable Timed Event Priority robustly
        GuiControl, Disable, PriorityIH
        GuiControl, Disable, PriorityVoid
        TooltipMap["PriorityIH"] := timed_event_tooltip_text
        TooltipMap["PriorityVoid"] := timed_event_tooltip_text

        Loop, 3 {
            GuiControl, Disable, AreaEnabled%A_Index%
            GuiControl, Disable, AreaSelection%A_Index%
            TooltipMap["AreaEnabled" . A_Index] := custom_tooltip_text
            TooltipMap["AreaSelection" . A_Index] := custom_tooltip_text
        }
        
        GuiControl, Disable, EnableAutoSell
        GuiControl, Disable, EnableInstantSell
        TooltipMap["EnableAutoSell"] := custom_tooltip_text
        TooltipMap["EnableInstantSell"] := custom_tooltip_text

    } else {
        GuiControl, +c8B0000, EnableCustomLocation
        GuiControl,, EnableCustomLocation, Custom-Location Disabled
        
        ; Enable Timed Event Priority robustly
        GuiControl, Enable, PriorityIH
        Gui, Submit, NoHide
        GuiControl, Enable, PriorityVoid
        TooltipMap.Remove("PriorityIH")
        TooltipMap.Remove("PriorityVoid")
        
        Loop, 3 {
            GuiControl, Enable, AreaEnabled%A_Index%
            GuiControl, Enable, AreaSelection%A_Index%
            TooltipMap.Remove("AreaEnabled" . A_Index)
            TooltipMap.Remove("AreaSelection" . A_Index)
        }
        GuiControl, Enable, EnableAutoSell
        GuiControl, Enable, EnableInstantSell
        TooltipMap.Remove("EnableAutoSell")
        TooltipMap.Remove("EnableInstantSell")
    }
    GoSub, UpdateLocationControls
return

OnLocationChange:
    ; *** ADDED: Intercept "VOID" selection ***
    GuiControlGet, new_selection_check, , %A_GuiControl%
    if (new_selection_check = "VOID") {
		; *** MODIFIED: Use flag to show tooltip reliably ***
        global blockTooltipClear
        blockTooltipClear := true
        ToolTip, This Location was removed in-game
        SetTimer, RemoveToolTip, -2000

        trigger_slot_num_void := SubStr(A_GuiControl, StrLen("AreaSelection") + 1)
        if (trigger_slot_num_void = 1)
            old_selection_void := activeAreaSelection1
        else if (trigger_slot_num_void = 2)
            old_selection_void := activeAreaSelection2
        else
            old_selection_void := activeAreaSelection3

        GuiControl, Choose, %A_GuiControl%, %old_selection_void%
        return
    }
    ; *** END OF ADDED CODE ***

    Gui, Submit, NoHide
    global activeAreaSelection1, activeAreaSelection2, activeAreaSelection3, AreaSelection1, AreaSelection2, AreaSelection3
    
    trigger_control := A_GuiControl
    trigger_slot_num := SubStr(trigger_control, StrLen("AreaSelection") + 1)

    GuiControlGet, new_selection, , %trigger_control%
    
    if (trigger_slot_num = 1)
        old_selection := activeAreaSelection1
    else if (trigger_slot_num = 2)
        old_selection := activeAreaSelection2
    else
        old_selection := activeAreaSelection3
    
    if (new_selection = old_selection)
        return

    other_slot_num_to_swap := 0
    Loop, 3 {
        current_loop_slot_num := A_Index
        if (current_loop_slot_num = trigger_slot_num)
            continue
        
        GuiControlGet, other_slot_selection, , AreaSelection%current_loop_slot_num%
        if (new_selection = other_slot_selection) {
            other_slot_num_to_swap := current_loop_slot_num
            break
        }
    }

    if (other_slot_num_to_swap > 0) { 
        other_control := "AreaSelection" . other_slot_num_to_swap
        GuiControl, Choose, %other_control%, %old_selection%

        if (trigger_slot_num = 1)
            activeAreaSelection1 := new_selection
        else if (trigger_slot_num = 2)
            activeAreaSelection2 := new_selection
        else if (trigger_slot_num = 3)
            activeAreaSelection3 := new_selection

        if (other_slot_num_to_swap = 1)
            activeAreaSelection1 := old_selection 
        else if (other_slot_num_to_swap = 2)
            activeAreaSelection2 := old_selection
        else if (other_slot_num_to_swap = 3)
            activeAreaSelection3 := old_selection
    } else {
        if (trigger_slot_num = 1)
            activeAreaSelection1 := new_selection
        else if (trigger_slot_num = 2)
            activeAreaSelection2 := new_selection
        else if (trigger_slot_num = 3)
            activeAreaSelection3 := new_selection
    }
    
    GoSub, UpdateLocationControls
return

; *** ADDED: New subroutine to handle clicks on the Void priority radio button ***
OnPriorityVoidSelect:
	; *** MODIFIED: Use flag to show tooltip reliably ***
    global blockTooltipClear
    blockTooltipClear := true
    ToolTip, This Location was removed in-game
    SetTimer, RemoveToolTip, -2000
    GuiControl,, PriorityIH, 1
return
; *** END OF ADDED CODE ***

ToggleAutoSell:
    Gui, Submit, NoHide
    if (EnableAutoSell) {
        GuiControl, +c32CD32, EnableAutoSell
        GuiControl,, EnableAutoSell, Merchant-Auto-Sell Enabled
        GuiControl,, EnableInstantSell, 0
        GoSub, ToggleInstantSell
    } else {
        GuiControl, +c8B0000, EnableAutoSell
        GuiControl,, EnableAutoSell, Merchant-Auto-Sell Disabled
    }
return

ToggleInstantSell:
    Gui, Submit, NoHide
    if (EnableInstantSell) {
        GuiControl, +c32CD32, EnableInstantSell
        GuiControl,, EnableInstantSell, Instant-Sell-Gamepass Enabled
        GuiControl,, EnableAutoSell, 0
        GoSub, ToggleAutoSell
    } else { 
        GuiControl, +c8B0000, EnableInstantSell
        GuiControl,, EnableInstantSell, Instant-Sell-Gamepass Disabled
    }
return

ToggleLoadoutSwitcher:
    Gui, Submit, NoHide
    global TooltipMap
    if (EnableLoadoutSwitcher) {
        GuiControl, +c32CD32, EnableLoadoutSwitcher
        GuiControl,, EnableLoadoutSwitcher, Loadout Switching Enabled
        GuiControl, Enable, MainLoadout
        GuiControl, Enable, SellLoadout
        TooltipMap.Remove("MainLoadout")
        TooltipMap.Remove("SellLoadout")
    } else {
        GuiControl, +c8B0000, EnableLoadoutSwitcher
        GuiControl,, EnableLoadoutSwitcher, Enable Loadout Switching
        GuiControl, Disable, MainLoadout
        GuiControl, Disable, SellLoadout
        TooltipMap["MainLoadout"] := "Enable Loadout Switching to use this."
        TooltipMap["SellLoadout"] := "Enable Loadout Switching to use this."
    }
return

ToggleRenewLuck:
    GuiControlGet, renewLuck,, RenewLuck
    global TooltipMap
    if (renewLuck) {
        GuiControl, Enable, LuckPotions
        TooltipMap.Remove("LuckPotions")
    } else {
        GuiControl, Disable, LuckPotions
        GuiControl,, LuckPotions, 0
        TooltipMap["LuckPotions"] := "Tick the 'Basic Luck' checkbox to enable this."
        GoSub, UpdateLuckPotions
    }
return

UpdateLuckPotions:
    GuiControlGet, luckCount,, LuckPotions
    luckCount := (luckCount ~= "^\d+$") ? luckCount : 0
    duration := Round((luckCount * 10) / 60, 2)
    GuiControl,, LuckDurationText, You will have %duration% hours of Luck.
return

ToggleRenewCapacity:
    GuiControlGet, renewCap,, RenewCapacity
    global TooltipMap
    if (renewCap) {
        GuiControl, Enable, CapacityPotions
        TooltipMap.Remove("CapacityPotions")
    } else {
        GuiControl, Disable, CapacityPotions
        GuiControl,, CapacityPotions, 0
        TooltipMap["CapacityPotions"] := "Tick the 'Basic Capacity' checkbox to enable this."
        GoSub, UpdateCapacityPotions
    }
return

UpdateCapacityPotions:
    GuiControlGet, capCount,, CapacityPotions
    capCount := (capCount ~= "^\d+$") ? capCount : 0
    duration := Round((capCount * 10) / 60, 2)
    GuiControl,, CapacityDurationText, You will have %duration% hours of Capacity.
return

ToggleRenewGreaterLuck:
    GuiControlGet, renew,, RenewGreaterLuck
    global TooltipMap
    if (renew) {
        GuiControl, Enable, GreaterLuckPotions
        TooltipMap.Remove("GreaterLuckPotions")
    } else {
        GuiControl, Disable, GreaterLuckPotions
        GuiControl,, GreaterLuckPotions, 0
        TooltipMap["GreaterLuckPotions"] := "Tick the 'Greater Luck' checkbox to enable this."
        GoSub, UpdateGreaterLuckPotions
    }
return

UpdateGreaterLuckPotions:
    GuiControlGet, count,, GreaterLuckPotions
    count := (count ~= "^\d+$") ? count : 0
    duration := Round((count * 20) / 60, 2)
    GuiControl,, GreaterLuckDurationText, You will have %duration% hours of Greater Luck.
return

ToggleRenewGreaterCapacity:
    GuiControlGet, renew,, RenewGreaterCapacity
    global TooltipMap
    if (renew) {
        GuiControl, Enable, GreaterCapacityPotions
        TooltipMap.Remove("GreaterCapacityPotions")
    } else {
        GuiControl, Disable, GreaterCapacityPotions
        GuiControl,, GreaterCapacityPotions, 0
        TooltipMap["GreaterCapacityPotions"] := "Tick the 'Greater Capacity' checkbox to enable this."
        GoSub, UpdateGreaterCapacityPotions
    }
return

UpdateGreaterCapacityPotions:
    GuiControlGet, count,, GreaterCapacityPotions
    count := (count ~= "^\d+$") ? count : 0
    duration := Round((count * 20) / 60, 2)
    GuiControl,, GreaterCapacityDurationText, You will have %duration% hours of Greater Capacity.
return

UpdateVolcanicLuckPotions:
    GuiControlGet, count,, VolcanicLuckPotionCount
    count := (count ~= "^\d+$") ? count : 0
    duration := Round(count * 0.16666666666, 2)
    GuiControl,, VolcanicLuckDurationText, You will have %duration% hours of Volcanic Luck.
return

UpdateVolcanicStrengthPotions:
    GuiControlGet, count,, VolcanicStrengthPotionCount
    count := (count ~= "^\d+$") ? count : 0
    duration := Round(count * 0.16666666666, 2)
    GuiControl,, VolcanicStrengthDurationText, You will have %duration% hours of Volcanic Strength.
return

UpdateSupremeLuckPotions:
    GuiControlGet, count,, SupremeLuckPotionCount
    count := (count ~= "^\d+$") ? count : 0
    duration := Round(count * 0.33333333333, 2)
    GuiControl,, SupremeLuckDurationText, You will have %duration% hours of Supreme Luck.
return

ToggleRenewLuckTotem:
    GuiControlGet, renew,, RenewLuckTotem
    global TooltipMap
    if (renew) {
        GuiControl, Enable, LuckTotemCount
        GuiControl, Enable, LuckTotemOwned
        TooltipMap.Remove("LuckTotemCount")
        TooltipMap.Remove("LuckTotemOwned")
    } else {
        GuiControl, Disable, LuckTotemCount
        GuiControl, Disable, LuckTotemOwned
        GuiControl,, LuckTotemCount, 0
        GuiControl,, LuckTotemOwned, 0
        TooltipMap["LuckTotemCount"] := "Tick the 'Luck Totems' checkbox to enable this."
        TooltipMap["LuckTotemOwned"] := "Tick the 'Luck Totems' checkbox to enable this."
    }
return

ToggleRenewStrengthTotem:
    GuiControlGet, renew,, RenewStrengthTotem
    global TooltipMap
    if (renew) {
        GuiControl, Enable, StrengthTotemCount
        GuiControl, Enable, StrengthTotemOwned
        TooltipMap.Remove("StrengthTotemCount")
        TooltipMap.Remove("StrengthTotemOwned")
    } else {
        GuiControl, Disable, StrengthTotemCount
        GuiControl, Disable, StrengthTotemOwned
        GuiControl,, StrengthTotemCount, 0
        GuiControl,, StrengthTotemOwned, 0
        TooltipMap["StrengthTotemCount"] := "Tick the 'Strength Totems' checkbox to enable this."
        TooltipMap["StrengthTotemOwned"] := "Tick the 'Strength Totems' checkbox to enable this."
    }
return

ToggleRenewMerchantsPotion:
    GuiControlGet, renew,, RenewMerchantsPotion
    global TooltipMap
    if (renew) {
        GuiControl, Enable, MerchantsPotionCount
        TooltipMap.Remove("MerchantsPotionCount")
    } else {
        GuiControl, Disable, MerchantsPotionCount
        GuiControl,, MerchantsPotionCount, 0
        TooltipMap["MerchantsPotionCount"] := "Tick the 'Merchant''s Potion' checkbox to enable this."
    }
return

ToggleRenewVolcanicLuck:
    GuiControlGet, renew,, RenewVolcanicLuck
    global TooltipMap
    if (renew) {
        GuiControl, Enable, VolcanicLuckPotionCount
        TooltipMap.Remove("VolcanicLuckPotionCount")
    } else {
        GuiControl, Disable, VolcanicLuckPotionCount
        GuiControl,, VolcanicLuckPotionCount, 0
        TooltipMap["VolcanicLuckPotionCount"] := "Tick the 'Volcanic Luck' checkbox to enable this."
        GoSub, UpdateVolcanicLuckPotions
    }
return

ToggleRenewVolcanicStrength:
    GuiControlGet, renew,, RenewVolcanicStrength
    global TooltipMap
    if (renew) {
        GuiControl, Enable, VolcanicStrengthPotionCount
        TooltipMap.Remove("VolcanicStrengthPotionCount")
    } else {
        GuiControl, Disable, VolcanicStrengthPotionCount
        GuiControl,, VolcanicStrengthPotionCount, 0
        TooltipMap["VolcanicStrengthPotionCount"] := "Tick the 'Volcanic Strength' checkbox to enable this."
        GoSub, UpdateVolcanicStrengthPotions
    }
return

ToggleRenewSupremeLuck:
    GuiControlGet, renew,, RenewSupremeLuck
    global TooltipMap
    if (renew) {
        GuiControl, Enable, SupremeLuckPotionCount
        TooltipMap.Remove("SupremeLuckPotionCount")
    } else {
        GuiControl, Disable, SupremeLuckPotionCount
        GuiControl,, SupremeLuckPotionCount, 0
        TooltipMap["SupremeLuckPotionCount"] := "Tick the 'Supreme Luck' checkbox to enable this."
        GoSub, UpdateSupremeLuckPotions
    }
return

UpdateLocationControls:
    Gui, Submit, NoHide
    global TooltipMap, EnableCustomLocation

    if (EnableCustomLocation) {
        return
    }

    totalEnabledAreas := (AreaEnabled1 + AreaEnabled2 + AreaEnabled3)

    Loop, 3
    {
        GuiControlGet, isSlotEnabled, , AreaEnabled%A_Index%

        if (!isSlotEnabled)
        {
            GuiControl, Disable, AreaSelection%A_Index%
            GuiControl, Disable, AreaDuration%A_Index%
            TooltipMap["AreaSelection" . A_Index] := "Enable Slot " . A_Index . " to configure."
            TooltipMap["AreaDuration" . A_Index] := "Enable Slot " . A_Index . " to configure."
            continue
        }

        GuiControl, Enable, AreaSelection%A_Index%
        TooltipMap.Remove("AreaSelection" . A_Index)
        GuiControlGet, currentSelection, , AreaSelection%A_Index%
        isInfernalHeart := (currentSelection = "THE INFERNAL HEART")

        if (totalEnabledAreas = 1)
        {
            if (isInfernalHeart) {
                GuiControl,, AreaDuration%A_Index%, -
            }
            else
            {
                GuiControl,, AreaDuration%A_Index%, Infinite
            }
            GuiControl, Disable, AreaDuration%A_Index%
            TooltipMap["AreaDuration" . A_Index] := "Duration is not applicable when only one location is enabled."
        }
        else
        {
            GuiControl, Enable, AreaDuration%A_Index%
            TooltipMap.Remove("AreaDuration" . A_Index)
            GuiControlGet, currentDuration, , AreaDuration%A_Index%
            if (currentDuration = "-")
            {
                GuiControl,, AreaDuration%A_Index%, 30
            }
            else if (currentDuration = "Infinite")
            {
                GuiControl,, AreaDuration%A_Index%, 60
            }
        }
    }
return

buyPotionAlignment:
    Sleep, 300
    Loop, 40 {
        Send, {WheelUp}
        Sleep, 10
    }
    Sleep, 200
    Loop, 4 {
        Send, {WheelDown}
        Sleep, 10
    }
	Sleep, 200
Return

finishedBuyPotionAlignment:
    Sleep, 300
    Loop, 40 {
        Send, {WheelUp}
        Sleep, 10
    }
    Sleep, 200
    Loop, 8 {
        Send, {WheelDown}
        Sleep, 10
    }
	Sleep, 200
Return

SaveChanges:
    SaveSettings()
    ToolTip, Settings Saved!
    SetTimer, RemoveToolTip, -2000
return

RemoveToolTip:
    ToolTip
	; *** MODIFIED: Reset the flag after clearing the tooltip ***
    global blockTooltipClear
    blockTooltipClear := false
return

StartMacro:
    Critical
   
    if (!running) {
        Gui, Submit, NoHide
        SaveSettings()
        
        global PriorityVoid, TimedEventPriority
        if (PriorityVoid)
            TimedEventPriority := "VOID"
        else
            TimedEventPriority := "INFERNAL HEART"

        FocusRoblox()

		if (EnableCustomLocation) {
			running := true
			paused := false
			mainStopped := false
			Gui, Hide
			holdTime := GetHoldTime(DigspeedInput)
			SetTimer, MainLoopTimer, -10
			return
		}

        enabledCount := 0
        Loop, 3 {
            if (AreaEnabled%A_Index%) {
                enabledCount++
            }
        }

        if (enabledCount = 0) {
            MsgBox, 48, Ornate Macro Error, You must enable at least one location.
            return
        }
        
        normalLocationsEnabled := 0
        Loop, 3 {
            if (AreaEnabled%A_Index%) {
                currentSelection := AreaSelection%A_Index%
                isTimedLocation := (currentSelection = "THE INFERNAL HEART" or currentSelection = "VOID")
                if (!isTimedLocation) {
                    normalLocationsEnabled++
                }
            }
        }

        if (normalLocationsEnabled = 0) {
            MsgBox, 48, Ornate Macro Error, You must enable at least one non-timed location.`nRunning with only 'Infernal Heart' and/or 'Void' is not supported.
            return
        }
		
		Loop, 3 {
			if(AreaEnabled%A_Index%){
				currentSelection := AreaSelection%A_Index%
				currentDuration := AreaDuration%A_Index%
				isTimedLocation := (currentSelection = "THE INFERNAL HEART" or currentSelection = "VOID")

				if (isTimedLocation) {
					if (currentDuration < 5 or currentDuration > 28) {
						MsgBox, 48, Ornate Macro Error, Duration for a timed location (Slot %A_Index%) must be between 5 and 28 minutes!
						return
					}
				}
			}
		}

        FormatTime, currentMinute, A_NowUTC, m
        IHD := 45 - currentMinute
        global previousIHRange := GetIHD_Range(IHD)

        currentAreaIndex := FindInitialArea()
        if (currentAreaIndex = 0) {
            MsgBox, 48, Ornate Macro Error, You must enable at least one location.
            return
        }

        running := true
        paused := false
        mainStopped := true
        hasSwitchedToIH := false

        SetTimer, LaunchSequence, -100
    }
return


CloseAhkByTitle(titleContains, thisPID) {
    static WM_COMMAND := 0x111, ID_EXIT := 65405, WM_CLOSE := 0x10

    ; Uncompiled scripts
    WinGet, list1, List, ahk_class AutoHotkey
    Loop % list1 {
        id := list1%A_Index%
        WinGet, pid, PID, ahk_id %id%
        if (pid = thisPID)
            continue
        WinGetTitle, t, ahk_id %id%
        if InStr(t, titleContains) {
            ; 1) ask nicely: Script → Exit
            PostMessage, %WM_COMMAND%, %ID_EXIT%,,, ahk_id %id%
            WinWaitClose, ahk_id %id%,, 0.7
            if WinExist("ahk_id " id) {
                ; 2) ask via WM_CLOSE
                PostMessage, %WM_CLOSE%, 0, 0,, ahk_id %id%
                WinWaitClose, ahk_id %id%,, 0.7
            }
            if WinExist("ahk_id " id) {
                ; 3) last resort: kill process
                Process, Close, %pid%
            }
        }
    }

    ; Compiled scripts (.exe) use a different window class
    WinGet, list2, List, ahk_class AutoHotkeySC
    Loop % list2 {
        id := list2%A_Index%
        WinGet, pid, PID, ahk_id %id%
        if (pid = thisPID)
            continue
        WinGetTitle, t, ahk_id %id%
        if InStr(t, titleContains) {
            PostMessage, %WM_COMMAND%, %ID_EXIT%,,, ahk_id %id%
            WinWaitClose, ahk_id %id%,, 0.7
            if WinExist("ahk_id " id) {
                PostMessage, %WM_CLOSE%, 0, 0,, ahk_id %id%
                WinWaitClose, ahk_id %id%,, 0.7
            }
            if WinExist("ahk_id " id) {
                Process, Close, %pid%
            }
        }
    }
}



; --- Close all other running AutoHotkey scripts (leave this PID alone) ---
CloseOtherAhkScripts(thisPID) {
    static WM_COMMAND := 0x111, ID_EXIT := 65405, WM_CLOSE := 0x10

    DetectHiddenWindows, On
    SetTitleMatchMode, 2

    ; Uncompiled scripts (ahk files)
    WinGet, list1, List, ahk_class AutoHotkey
    Loop % list1 {
        id := list1%A_Index%
        WinGet, pid, PID, ahk_id %id%
        if (pid = thisPID)
            continue
        ; Menu: Script → Exit
        PostMessage, %WM_COMMAND%, %ID_EXIT%,,, ahk_id %id%
        WinWaitClose, ahk_id %id%,, 500
        if WinExist("ahk_id " id) {
            ; try WM_CLOSE
            PostMessage, %WM_CLOSE%, 0, 0,, ahk_id %id%
            WinWaitClose, ahk_id %id%,, 500
        }
        if WinExist("ahk_id " id)
            Process, Close, %pid%
    }

    ; Compiled scripts (.exe)
    WinGet, list2, List, ahk_class AutoHotkeySC
    Loop % list2 {
        id := list2%A_Index%
        WinGet, pid, PID, ahk_id %id%
        if (pid = thisPID)
            continue
        PostMessage, %WM_COMMAND%, %ID_EXIT%,,, ahk_id %id%
        WinWaitClose, ahk_id %id%,, 500
        if WinExist("ahk_id " id) {
            PostMessage, %WM_CLOSE%, 0, 0,, ahk_id %id%
            WinWaitClose, ahk_id %id%,, 500
        }
        if WinExist("ahk_id " id)
            Process, Close, %pid%
    }
}



StopMacro:
    Critical

    ; Stop loops and timers
    running := false
    paused := false
    mainStopped := true

    for _, t in ["LaunchSequence","StartMainScript","RestartFromNavigation","MainLoopTimer","SpamClickTimer","DoubleCheckPanEmpty","DiggingFallback","PanningFallback","RemoveToolTip"] {
        SetTimer, %t%, Off
    }

    ; Release any held keys / mouse
    SendInput {LButton up}{RButton up}{MButton up}
    SendInput {w up}{a up}{s up}{d up}{Space up}{Left up}{Right up}{Shift up}{Ctrl up}{Alt up}

    ; Close other AHK scripts (uncompiled & compiled)
    thisPID := DllCall("GetCurrentProcessId", "UInt")
    CloseOtherAhkScripts(thisPID)

    ; Relaunch Controller.ahk alone, then exit
    ctrlPath := A_ScriptFullPath  ; current Controller.ahk path
    if (!FileExist(ctrlPath)) {
        ; fallback if launched via wrapper
        if (FileExist(A_ScriptDir "\Modules\Controller.ahk"))
            ctrlPath := A_ScriptDir "\Modules\Controller.ahk"
        else
            ctrlPath := A_ScriptDir "\Controller.ahk"
    }
    Run, %ctrlPath%
    ExitApp
return



LaunchSequence:
    Gui, Hide
    SendReset()
    HotbarMove()
    Send, {/ down}
    Sleep, 50
    Send, {/ up}
    Click
    global luckTotemsRemaining := (RenewLuckTotem and LuckTotemCount > 0) ? LuckTotemCount : 0
    global strengthTotemsRemaining := (RenewStrengthTotem and StrengthTotemCount > 0) ? StrengthTotemCount : 0
    global merchantsPotionsRemaining := (RenewMerchantsPotion and MerchantsPotionCount > 0) ? MerchantsPotionCount : 0
    global autoSellCounter := 0
    lastLuckTotemPlacementTime := 0
    lastStrengthTotemPlacementTime := 0
	areaPausedTime1 := 0, areaPausedTime2 := 0, areaPausedTime3 := 0
    currentAreaStartTime := A_TickCount
    holdTime := GetHoldTime(DigspeedInput)

    HandleBuffPurchaseSequence()

    if (!running) {
        mainStopped := true
        return
    }

    mainStopped := false
    SetTimer, StartMainScript, -100
return

FindInitialArea() {
    global AreaEnabled1, AreaEnabled2, AreaEnabled3, AreaSelection1, AreaSelection2, AreaSelection3, TimedEventPriority
    Gui, Submit, NoHide

    ; --- Timed Event Priority Logic ---
    isVoidActive := IsVoidTimeViable()
    isIH_Active := IsIH_Active()
    
    ; Find available timed slots
    voidSlot := 0
    ihSlot := 0
    Loop, 3 {
        if (AreaEnabled%A_Index%) {
            if (AreaSelection%A_Index% = "VOID")
                voidSlot := A_Index
            if (AreaSelection%A_Index% = "THE INFERNAL HEART")
                ihSlot := A_Index
            } 
    }

    if (TimedEventPriority = "VOID") {
        if (isVoidActive and voidSlot > 0)
            return voidSlot
        if (isIH_Active and ihSlot > 0)
            return ihSlot
    } else { ; TimedEventPriority is "INFERNAL HEART"
        if (isIH_Active and ihSlot > 0)
            return ihSlot
        if (isVoidActive and voidSlot > 0)
            return voidSlot
    }

    ; --- Fallback to the first available non-timed location ---
    Loop, 3 {
        if (AreaEnabled%A_Index%) {
            isIHSlot := (AreaSelection%A_Index% = "THE INFERNAL HEART")
            isVoidSlot := (AreaSelection%A_Index% = "VOID")
            if (!isIHSlot and !isVoidSlot) {
                return A_Index
            }
        }
    }

    ; The "at least one non-timed location" check in F6 hotkey ensures a location is found.
    ; If code reaches here, it means no suitable location was found, so return 0 to trigger an error.
    return 0
}


; --- Close all scripts when the window's [X] is clicked (and on Esc) ---
GuiClose:
GuiEscape:
    Critical
    DetectHiddenWindows, On
    SetTitleMatchMode, 2

    ; release anything that might still be held down
    SendInput {w up}{a up}{s up}{d up}{LButton up}{Space up}{Left up}{Right up}

    scriptsToClose := ["Controller.ahk","main.ahk","Script1.ahk","Script2.ahk","Script3.ahk","Script4.ahk","Script5.ahk","Script6.ahk","Script7.ahk","Script8.ahk","Script9.ahk","Script10.ahk","Script11.ahk","Script12.ahk","Script13.ahk","Script14.ahk"]

    thisPID := DllCall("GetCurrentProcessId", "UInt")

    ; try graceful exit, escalate if needed
    for attempt, _ in [1,2] {
        for _, name in scriptsToClose
            CloseAhkByTitle(name, thisPID)
        Sleep, 200
    }

    Sleep, 200
    ExitApp
return



StartMainScript:
    global mainStopped, DigspeedInput, runningScriptPIDs, currentAreaIndex, currentAreaStartTime
    global AreaSelection1, AreaSelection2, AreaSelection3, areaPausedTime1, areaPausedTime2, areaPausedTime3
    Gui, Submit, NoHide

    Loop {
        currentSelection := AreaSelection%currentAreaIndex%
        isInfernalHeart := (currentSelection = "THE INFERNAL HEART")

        if (isInfernalHeart) {
            FormatTime, currentMinute, A_NowUTC, m
            IHD := 45 - currentMinute

            ; ***** THIS IS THE FIX *****
            ; Changed "IHD < 5" to "IHD < 4" to prevent the switch from being cancelled
            ; due to script delays near the end of the event window.
            if (IHD < 4 or IHD > 30) {
                currentAreaIndex := FindNextAreaIndex(currentAreaIndex)
                continue 
            }
        }
        break
    }

    duration := AreaDuration%currentAreaIndex%
    
	pausedTime := areaPausedTime%currentAreaIndex%
	if (pausedTime > 0) {
		currentAreaStartTime := A_TickCount - pausedTime
		areaPausedTime%currentAreaIndex% := 0
	} else {
		currentAreaStartTime := A_TickCount
	}

    scriptNum := GetSelectedScriptNumber(currentSelection)
    scriptFile := "Script" . scriptNum . ".ahk"

    navigationDelayMS := NavigationDelaySecs * 1000

mainStopped := true
    Run, %scriptFile% %DigspeedInput%, , , tempPID
    Run, %scriptFile% %DigspeedInput% %navigationDelayMS%, , , tempPID
    runningScriptPIDs[scriptNum] := tempPID
    Process, WaitClose, %tempPID%
    runningScriptPIDs[scriptNum] := 0

    if (!running)
        return

    mainStopped := false
    SetTimer, MainLoopTimer, -10
return

MainLoopTimer:
    MainLoop()
return

MainLoop() {
    global

    while (running and !mainStopped) {
        if (!EnableCustomLocation) {


            if (CheckForVoidInterrupt()) {
                continue
            }
            if (CheckForInfernalHeartInterrupt()) {
                continue
            }
            if (CheckAndPerformSwitch()) {

                continue
            }
        }

        effectiveTime := GetEffectiveGrindTime()

        if (effectiveTime >= 25 and !EnableCustomLocation) {
            if (RenewLuckTotem and luckTotemsRemaining > 0 and (A_TickCount - lastLuckTotemPlacementTime > totemCooldown)) {
                PlaceSingleLuckTotem()
                luckTotemsRemaining--
                lastLuckTotemPlacementTime := A_TickCount
            }

            if (RenewStrengthTotem and strengthTotemsRemaining > 0 and (A_TickCount - lastStrengthTotemPlacementTime > totemCooldown)) {
                PlaceSingleStrengthTotem()
                strengthTotemsRemaining--
                lastStrengthTotemPlacementTime := A_TickCount
            }
        }

        if (!EnableCustomLocation)
            SetTimer, DiggingFallback, % -(DiggingFallbackDelay * 1000)

        while (running and !mainStopped) {
            ; The condition below is changed to check for EITHER auto-sell OR instant-sell.
            if ((EnableAutoSell or EnableInstantSell) and !EnableCustomLocation) {
                if (LeftOfPan()) {
                    if (panEmptyStartTime = 0) {
                        panEmptyStartTime := A_TickCount
                    }
                } else {
                    panEmptyStartTime := 0
                }
                if (panEmptyStartTime > 0 and (A_TickCount - panEmptyStartTime > 5000)) {
                    if (!EnableCustomLocation)
                        SetTimer, DiggingFallback, Off
         

                    if (EnableInstantSell) {
                        ; === MODIFIED: Loadout switching logic for Gamepass Sell ===
                        ; Switch to Sell Loadout BEFORE selling
                        if (EnableLoadoutSwitcher) {
                            if (SellLoadout = "Loadout 1")
                                Loadout1()
                            else if (SellLoadout = "Loadout 2")
                                Loadout2()
                            else if (SellLoadout = "Loadout 3")
                                Loadout3()
                        }
                        GamepassSell() 
                            SleepWithCheck(MerchantDelay * 1000)
                            

                        ; Switch back to Main Loadout AFTER selling
                        if (EnableLoadoutSwitcher) {
                            if (MainLoadout = "Loadout 1")
                                Loadout1()
                            else if (MainLoadout = "Loadout 2")
                                Loadout2()
                            else if (MainLoadout = "Loadout 3")
                                Loadout3()
                                Send, {1}

                        }


                    } else {
                        ; === NEW: Loadout switching logic for Merchant Sell ===
                        ; Switch to Sell Loadout BEFORE selling
                        if (EnableLoadoutSwitcher) {
                            if (SellLoadout = "Loadout 1")
                                Loadout1()
                            else if (SellLoadout = "Loadout 2")
                                Loadout2()
                            else if (SellLoadout = "Loadout 3")
                                Loadout3()
                        }

                        RunFullAutoSellCycle() ; This is the original function for the merchant.

                        ; Switch back to Main Loadout AFTER selling
                        if (EnableLoadoutSwitcher) {
                            if (MainLoadout = "Loadout 1")
                                Loadout1()
                            else if (MainLoadout = "Loadout 2")
                                Loadout2()
                            else if (MainLoadout = "Loadout 3")
                                Loadout3()
                        }
                    }
                    panEmptyStartTime := 0

                    ; This check is now more specific to only restart when the merchant cycle runs.
                    if (EnableAutoSell and sellCycleCausedReset) {
                        SetTimer, StartMainScript, -100
                        return
                    }
                    continue 2
                }
            }
            ; --- MODIFICATION END ---

            if (RightOfPan()) {
                if (!EnableCustomLocation)
                    SetTimer, DiggingFallback, Off
                break
            }

            if (CenterOfT()) {
                Sleep, 20

                digStartTime := A_TickCount
                Click, down

                while (A_TickCount - digStartTime < holdTime) {
                    if (!running or mainStopped) {
                        Click, up
                        return
                    }
                    Sleep, 15
                }
                Click, up
                Sleep, 15
            }


            if (!running or mainStopped)
                return
            Sleep, 10
        }
        if (!running or mainStopped) {
            if (!EnableCustomLocation)
                SetTimer, DiggingFallback, Off
            return
        }

        if (!EnableCustomLocation)
            SetTimer, DiggingFallback, % -(DiggingFallbackDelay * 1000)
        Send, {w down}
        while (running and !mainStopped) {
            if (CenterOfP()) {
                Sleep, 150
                break
            }
            if (!running or mainStopped)
                break
            Sleep, 150
        }
        Send, {w up}
        if (!EnableCustomLocation)
            SetTimer, DiggingFallback, Off
        Sleep, 250
        if (!running or mainStopped)
            return

        SetTimer, SpamClickTimer, 50

        Sleep, 2500

        Send, {s down}
        if (!EnableCustomLocation)
            SetTimer, PanningFallback, % -(PanningFallbackDelay * 1000)

        while (running and !mainStopped) {
            if (LeftOfPan()) {
                SetTimer, SpamClickTimer, Off
                if (!EnableCustomLocation)
                    SetTimer, PanningFallback, Off
                spamActive := 1
                SetTimer, DoubleCheckPanEmpty, 50
                ResetGroundPrompt()
                break
            }
            Sleep, 10
        }


        if (!running or mainStopped) {
            if (!EnableCustomLocation)
                SetTimer, PanningFallback, Off
            SetTimer, SpamClickTimer, Off
            Click, up
            Sleep, 100
            Send, {s up}
            return
        }

        if (!EnableCustomLocation)
            SetTimer, DiggingFallback, % -(DiggingFallbackDelay * 1000)
        while (running and !mainStopped) {
            ; if (!CenterOfT()) {
            ; ResetGroundPrompt()
            ; continue
            ; }
            if (CenterOfT()) {
                spamActive := 0
                SetTimer, DoubleCheckPanEmpty, Off
                Sleep, 100
                Send, {s up}
                break
            }
            if (!running or mainStopped) {
                break
            }
            Sleep, 50
        }
        if (!running or mainStopped) {
            return
        }

        if (!EnableCustomLocation)
            SetTimer, DiggingFallback, Off
    }
}

PanningFallback:
    ToolTip, Panning Fallback Triggered!
    SetTimer, RemoveToolTip, -2000
    mainStopped := true
    spamActive := 0
    SetTimer, SpamClickTimer, Off
    Click, up
    Send, {s up}
    
    clickStartTime := A_TickCount
    while (A_TickCount - clickStartTime < 7000) {
        if (!running) return
        Click
        Sleep, 50
    }
    
    SetTimer, RestartFromNavigation, -100
return

DiggingFallback:
    ToolTip, Digging Fallback Triggered!
    SetTimer, RemoveToolTip, -2000 
    mainStopped := true
    SetTimer, RestartFromNavigation, -100
Return

RestartFromNavigation:
    SendReset()
    SetTimer, StartMainScript, -100
return

DoubleCheckPanEmpty:
    CheckPanEmpty()
return

SpamClickTimer:
    Send, {Click down}
    Sleep, 50
    Send, {Click up}
return

CheckPanEmpty() {
    global spamActive
    static isDown := false
    static t0 := 0

    if (!spamActive) {
        if (isDown) {
            Click, up
            isDown := false
        }
        return
    }

    if (!isDown) {
        Click, down
        t0 := A_TickCount
        isDown := true
        return
    }

    if (A_TickCount - t0 >= 5000) {
        Click, up
        isDown := false
    }
}



GetEffectiveGrindTime() {
    global
    Gui, Submit, NoHide

    if (totalEnabledAreas <= 1) {
        currentSelection := AreaSelection%currentAreaIndex%
        isInfernalHeart := (currentSelection = "THE INFERNAL HEART")
        if (!isInfernalHeart) {
            return 999
        }
    }

    ihSlotEnabled := false
    Loop, 3 {
        if (A_Index != currentAreaIndex and AreaEnabled%A_Index% and AreaSelection%A_Index% = "THE INFERNAL HEART") {
            ihSlotEnabled := true
            break
        }
    }

    currentSelection := AreaSelection%currentAreaIndex%
    isCurrentSlotIH := (currentSelection = "THE INFERNAL HEART")
    userDuration := AreaDuration%currentAreaIndex%
    FormatTime, currentMinute, A_NowUTC, m

    if (isCurrentSlotIH) {
        ihd := 45 - currentMinute
        if (ihd < 5 or ihd > 30) {
            return 0
        }
        return Min(ihd, userDuration)
    }

    if (ihSlotEnabled) {
        timeUntilIHWindow = 0
        if (currentMinute >= 15 and currentMinute <= 40) {
            timeUntilIHWindow := 0
         } else if (currentMinute < 15) {
            timeUntilIHWindow := 15 - currentMinute
        } else {
            timeUntilIHWindow := (60 - currentMinute) + 15
        }
        return Min(userDuration, timeUntilIHWindow)
    }

    return userDuration
}

GetIHD_Range(IHD) {
    if (IHD >= 5 and IHD <= 30) {
         return "ACTIVE"
    } else if (IHD >= -14 and IHD <= 4) {
        return "IGNORE"
    } else if (IHD >= 31 and IHD <= 45) {
        return "IGNORE"
    }
    return "OUT_OF_BOUNDS"
}


CheckForVoidInterrupt() {
    global currentAreaIndex, AreaSelection1, AreaSelection2, AreaSelection3, currentAreaStartTime, areaPausedTime1, areaPausedTime2, areaPausedTime3, TimedEventPriority
    Gui, Submit, NoHide

    currentSelection := AreaSelection%currentAreaIndex%
    ; Don't interrupt if already in Void.
    if (currentSelection = "VOID") {
        return false
    }
    
    ; First, check if Void is even active. If not, don't continue.
    if (!IsVoidTimeViable()) {
        return false
    }

    ; --- MODIFIED PRIORITY CHECK ---
    ; Now that we know Void is active, check if Infernal Heart is ALSO active.
    ; Only apply priority if both events are running simultaneously.
    isIH_Active := IsIH_Active()
    if (isIH_Active and TimedEventPriority = "INFERNAL HEART") {
        return false ; Both are active, and IH has priority, so don't switch to Void.
    }

    ; If we reach here, a switch is needed. Find the target slot.
    targetSlot := 0
    Loop, 3 {
        if (AreaEnabled%A_Index% and AreaSelection%A_Index% = "VOID") {
            targetSlot := A_Index
            break
        }
    }

    if (targetSlot > 0) {
        ToolTip, Void is active! Switching...
        SetTimer, RemoveToolTip, -2000
        elapsed := A_TickCount - currentAreaStartTime
        areaPausedTime%currentAreaIndex% := elapsed

        PerformAreaSwitch(targetSlot)
        return true
    }

    return false
}

CheckForInfernalHeartInterrupt() {
    global currentAreaIndex, AreaSelection1, AreaSelection2, AreaSelection3, currentAreaStartTime, areaPausedTime1, areaPausedTixme2, areaPausedTime3, previousIHrange, TimedEventPriority
    Gui, Submit, NoHide

    currentSelection := AreaSelection%currentAreaIndex%
    ; Don't interrupt if already in Infernal Heart.
    if (currentSelection = "THE INFERNAL HEART") {
        return false
    }

    ; First, check if IH is even active. If not, don't continue.
    if (!IsIH_Active()) {
        previousIHRange := "INACTIVE"
        return false
    }
    
    ; --- MODIFIED PRIORITY CHECK ---
    ; Now that we know IH is active, check if Void is ALSO active.
    ; Only apply priority if both events are running simultaneously.
    isVoidActive := IsVoidTimeViable()
    if (isVoidActive and TimedEventPriority = "VOID") {
        return false ; Both are active, and Void has priority, so don't switch to IH.
    }

    ; This check ensures we only trigger the switch ONCE when the event becomes active.
    if (previousIHRange = "ACTIVE") {
        return false
    }

    previousIHRange := "ACTIVE"

    targetSlot := 0
    Loop, 3 {
         if (AreaEnabled%A_Index% and AreaSelection%A_Index% = "THE INFERNAL HEART") {
            targetSlot := A_Index
            break
        }
    }

	if (targetSlot > 0) {
        ToolTip, Infernal Heart is active! Switching...
        SetTimer, RemoveToolTip, -2000
		elapsed := A_TickCount - currentAreaStartTime
		areaPausedTime%currentAreaIndex% := elapsed

		PerformAreaSwitch(targetSlot)
		return true
	}

    return false
}

CheckAndPerformSwitch() {
    global totalEnabledAreas, currentAreaIndex, currentAreaStartTime, AreaDuration1, AreaDuration2, AreaDuration3
    Gui, Submit, NoHide

    currentSelection := AreaSelection%currentAreaIndex%
    isVoid := (currentSelection = "VOID")
    isInfernalHeart := (currentSelection = "THE INFERNAL HEART")

    ; --- Logic for Timed Events ---
    ; If we are in a timed event, the ONLY reason to switch is if its time is up.
    if (isVoid) {
        if (!IsVoidTimeViable()) {
            ToolTip, Void time has ended. Switching...
            SetTimer, RemoveToolTip, -2000
            PerformAreaSwitch()
            return true
        }
        ; If Void is still viable, we don't check duration, so we don't switch.
        return false
    }

    if (isInfernalHeart) {
        if (!IsIH_Active()) {
            ToolTip, Infernal Heart has ended. Switching...
            SetTimer, RemoveToolTip, -2000
            PerformAreaSwitch()
            return true
        }
        ; If IH is still active, we don't check duration, so we don't switch.
        return false
    }
    
    ; --- Logic for regular, duration-based events ---
    if (totalEnabledAreas <= 1) {
        return false
    }

    requiredDuration := AreaDuration%currentAreaIndex%
    elapsedMinutes := (A_TickCount - currentAreaStartTime) / 60000
    
    if (elapsedMinutes >= requiredDuration) {
        PerformAreaSwitch()
        return true
    }

    return false
}
PerformAreaSwitch(targetSlot := 0) {
    global mainStopped, currentAreaIndex, currentAreaStartTime, EnableAutoSell
    mainStopped := true
    Sleep, 500

    if (targetSlot > 0)
        currentAreaIndex := targetSlot
    else
        currentAreaIndex := FindNextAreaIndex(currentAreaIndex)

    currentAreaStartTime := A_TickCount
    
    if (EnableAutoSell) {
        RunFullAutoSellCycle()
        SetTimer, StartMainScript, -100
    } else {
        SetTimer, RestartFromNavigation, -100
    }
}

FindNextAreaIndex(startIndex) {
    global AreaEnabled1, AreaEnabled2, AreaEnabled3, AreaSelection1, AreaSelection2, AreaSelection3, areaPausedTime1, areaPausedTime2, areaPausedTime3, TimedEventPriority
    Gui, Submit, NoHide

    ; --- Timed Event Priority Logic ---
    isVoidActive := IsVoidTimeViable()
    isIH_Active := IsIH_Active()
    
    ; Find available timed slots
    voidSlot := 0
    ihSlot := 0
    Loop, 3 {
        if (AreaEnabled%A_Index%) {
            if (AreaSelection%A_Index% = "VOID")
                voidSlot := A_Index
            if (AreaSelection%A_Index% = "THE INFERNAL HEART")
                ihSlot := A_Index
            } 
    }

    if (TimedEventPriority = "VOID") {
        if (isVoidActive and voidSlot > 0)
            return voidSlot
        if (isIH_Active and ihSlot > 0)
            return ihSlot
    } else { ; TimedEventPriority is "INFERNAL HEART"
        if (isIH_Active and ihSlot > 0)
            return ihSlot
        if (isVoidActive and voidSlot > 0)
            return voidSlot
    }
    
    ; --- Fallback to next non-timed location in the rotation ---
    next := startIndex
    Loop, 3 {
        next++
        if (next > 3)
            next := 1

        if (AreaEnabled%next%) {
            isIHSlot := (AreaSelection%next% = "THE INFERNAL HEART")
            isVoidSlot := (AreaSelection%next% = "VOID")
            if (!isIHSlot and !isVoidSlot) {
                return next
            }
        }
    }

    ; --- Final fallback if rotation fails (e.g., only one non-timed area enabled) ---
    if (AreaEnabled%startIndex%) {
        isIHSlot := (AreaSelection%startIndex% = "THE INFERNAL HEART")
        isVoidSlot := (AreaSelection%startIndex% = "VOID")
        if (!isIHSlot and !isVoidSlot)
            return startIndex
    }
	
    ; The "at least one non-timed location" check ensures a non-timed location is always available to fall back to.
    ; Return 0 to indicate an error state if no location is found.
    return 0
}


HandleBuffPurchaseSequence() {
    global
    Gui, Submit, NoHide
    try {
        needsPotions := (RenewLuck and LuckPotions > 0) or (RenewCapacity and CapacityPotions > 0) or (RenewGreaterLuck and GreaterLuckPotions > 0) or (RenewGreaterCapacity and GreaterCapacityPotions > 0)
        
        luckTotemsToBuy := (LuckTotemCount - LuckTotemOwned)
        strengthTotemsToBuy := (StrengthTotemCount - StrengthTotemOwned)
        
        needsTotems := (RenewLuckTotem and luckTotemsToBuy > 0) or (RenewStrengthTotem and strengthTotemsToBuy > 0)
        needsMerchantsPotions := (EnableInstantSell and RenewMerchantsPotion and MerchantsPotionCount > 0)
        needsVolcanicPotions := (RenewVolcanicLuck and VolcanicLuckPotionCount > 0) or (RenewVolcanicStrength and VolcanicStrengthPotionCount > 0) or (RenewSupremeLuck and SupremeLuckPotionCount > 0)

        if (needsPotions) {
            PrePresequence()
            PresequenceP()
            movedToCapacity := false
            movedToGreaterLuck := false
            if (RenewLuck and LuckPotions > 0) {
                    CheckStop()
                    BuyBasicLuck()
Sleep, 100
    Send, %LuckPotions% ; Added this line to input the quantity
Sleep, 100
    BuyItemConfirm()
Sleep, 100
            }
             CheckStop()
            if (RenewCapacity and CapacityPotions > 0) {
                MoveFromBasicToCapacity()
                movedToCapacity := true
                    CheckStop()
                    BuyBasicCapacity()
Sleep, 100
    Send, %CapacityPotions% ; Added this line to input the quantity
Sleep, 100
    BuyItemConfirm()
Sleep, 100
             }
            CheckStop()
            if (RenewGreaterLuck and GreaterLuckPotions > 0) {
    if (!movedToCapacity) {
        MoveFromBasicToCapacity()
    }
    MoveFromBasicCapacityToGreaterLuck()
    movedToGreaterLuck := true
    
    CheckStop()
    BuyGreaterLuck() 
Sleep, 100
    Send, %GreaterLuckPotions%
Sleep, 100
    BuyItemConfirm()
Sleep, 100
             CheckStop()
            if (RenewGreaterCapacity and GreaterCapacityPotions > 0) {
    if (!movedToGreaterLuck) {
        if (!movedToCapacity) {
            MoveFromBasicToCapacity()
        } 
        MoveFromBasicCapacityToGreaterLuck()
    }
    MoveFromGreaterLuckToCapacity()

    CheckStop() 
    BuyGreaterCapacity()
Sleep, 100
    Send, %GreaterCapacityPotions%  ; Added this line to input the quantity
Sleep, 100
    BuyItemConfirm()
Sleep, 100
}
            CheckStop()
            PostSequence() 
        }
        CheckStop()
        if (needsTotems or needsMerchantsPotions) {
            PrePresequence()
            PresequenceTM()
            if (RenewLuckTotem and luckTotemsToBuy > 0) {
                Loop, %luckTotemsToBuy% {
                    CheckStop() 
                    BuyLuckTotem()
                    SleepWithCheck(500)
                }
             }

            if (needsMerchantsPotions) {
                MoveFromLuckToMerchant() 
                    CheckStop()
                    BuyMerchantsPotion()
Sleep, 100
    Send, %MerchantsPotionCount% ; Added this line to input the quantity
Sleep, 100
    BuyItemConfirm()
Sleep, 100
                    } 
                merchantsPotionsRemaining := 0
            }

            CheckStop()
            if (RenewStrengthTotem and strengthTotemsToBuy > 0) {
                if (!needsMerchantsPotions) {
                    MoveFromLuckToMerchant() 
                 }
                MoveFromMerchantToStrength()
                Loop, %strengthTotemsToBuy% {
                    CheckStop()
                    BuyStrengthTotem() 
                     SleepWithCheck(500)
                }
            }
            CheckStop()
            PostSequence()
        }

        CheckStop()
        if (needsVolcanicPotions) { 
             movedToVolcanicStrength := false
            movedToSupremeLuck := false
            PrePreSequenceVP()
            
            if (RenewVolcanicLuck and VolcanicLuckPotionCount > 0) {
                Loop, %VolcanicLuckPotionCount% {
                    CheckStop() 
                    BuyVolcanicLuckPotion()
                    SleepWithCheck(500)
                }
            }
            CheckStop()
            if (RenewVolcanicStrength and VolcanicStrengthPotionCount > 0) { 
                MoveFromVolcanicLuckPotionToVolcanicStrengthPotion()
                movedToVolcanicStrength := true
                Loop, %VolcanicStrengthPotionCount% {
                    CheckStop()
                    BuyVolcanicStrengthPotion()
                    SleepWithCheck(500) 
                }
            }
            CheckStop()
            if (RenewSupremeLuck and SupremeLuckPotionCount > 0) {
                if (!movedToVolcanicStrength) {
                    MoveFromVolcanicLuckPotionToVolcanicStrengthPotion() 
                }
                MoveFromVolcanicStrengthPotionToSupremeLuckPotion()
                movedToSupremeLuck := true
                Loop, %SupremeLuckPotionCount% {
                    CheckStop() 
                     BuySupremeLuckPotion()
                    SleepWithCheck(500)
                }
            }
            CheckStop()
            PostSequence()
        } 

     } catch e {
        if (e = "MacroStopped")
            return
        else
            throw e
    }
}

UseMerchantsPotion() {
    try {
        PrePresequence()
        PresequenceTM()
        MoveFromLuckToMerchant()
        BuyMerchantsPotion()
Sleep, 100
    Send, %MerchantsPotionCount% ; Added this line to input the quantity
Sleep, 100
    BuyItemConfirm()
Sleep, 100
        SendReset() 
     } catch e {
        if (e = "MacroStopped")
            return
        else
            throw e
    }
}


RunFullAutoSellCycle() {
    global
    try {
        if (!EnableAutoSell)
            return
        sellCycleCausedReset := false
        autoSellCounter++

        sellCycleCausedReset := true

        ; If auto-sell is enabled, and we need to use a potion, do it now.
        if (EnableAutoSell and RenewMerchantsPotion and merchantsPotionsRemaining > 0) {
            Sendreset()
            UseMerchantsPotion() ; Buys one potion and resets character
            merchantsPotionsRemaining--
        } else {
            ; If we didn't buy a potion, we still need to reset before selling.
            SendReset()
        }
        
        SleepWithCheck(2000)
        RunAutoSellMerchant()
        SendReset()

    } catch e {
        if (e = "MacroStopped")
             return
        else
            throw e
    }
}

RunAutoSellMerchant() {
    global MerchantDelay
    Send, {o down}
    Sleep, 800
    Send, {o up}
    Sleep, 50
    SleepWithCheck(200)
    Send, {Left down}
    Sleep, 1280
    Send, {Left up}
    Sleep, 50
    SleepWithCheck(200) 
    Send, {w down}
    Sleep, 1700
    Send, {w up}
    Sleep, 50
    SleepWithCheck(200)
	Loop 5 {
		Send, e
	}
	Sleep 300
    Loop, 15 {
        Send, {WheelUp}
        Sleep, 50
    }
    Sleep, 500
    Loop, 2 {
        Send, {WheelDown}
        Sleep, 50
    }
    Sleep 2000
    MerchantM1() 
	Loop 3 {
		Click
		Sleep 10
	}
     SleepWithCheck(3500)
     MerchantM2()
	Loop 5 {
		Click
		Sleep 10
	}
    SleepWithCheck(MerchantDelay * 1000)
	Loop, 15 {
        Send, {WheelUp}
        Sleep, 50
    }
    Sleep, 500
    Loop, 8 {
        Send, {WheelDown}
        Sleep, 50
    }
	HotbarMove()
	Sleep 1700
}

PrePreSequenceVP() {
    CheckStop()
Send, {w up}{a up}{s up}{d up}{LButton up}{Space up}{Left up}{Right up}
HotbarMove()
Send, {d down}
Sleep, 900
Send, {d up}
Sleep, 30 
Send, {s down}
Sleep, 3300
Send, {s up}
Sleep, 30
Send, {a down}
Sleep, 600
Send, {a up}
Sleep, 30
Send, {e down}
Sleep, 100
Send, {e up}
Sleep, 100
Send, {w}
Sleep, 100
VolcanicSandsTP()
NavigationSleep()
Sleep, 50
Click
Sleep, 50
HotbarMove()
Sleep, 400
Send, {d down}
Sleep, 500
Send, {d up}
Send, {s down}
Sleep, 4000
Send, {s up}
Send, {Right down}
Sleep, 1870
Send, {Right up}
Send, {a down}
Sleep, 990
Send, {a up}
Send, {w down}
Sleep, 990
Send, {w up}
Send, {s down}
Sleep, 220
Send, {s up}
Send, {a down}
Sleep, 5800
Send, {a up}
Send, {s down}
Sleep, 3350
Send, {s up}
Send, {a down}
Sleep, 8160
Send, {a up}
Send, {Left down}
Sleep, 380
Send, {Left up}

; X ALLIGNMENT
Send, {w down}
Sleep, 2260
Send, {w up}
Send, {a down}
Sleep, 1460
Send, {a up}
Send, {s down}
Sleep, 1960
Send, {s up}
; 0rnate
; Y ALLIGNMENT
Send, {a down}
Sleep, 2260
Send, {a up}
Send, {s down}
Sleep, 360
Send, {s up}
Send, {d down}
Sleep, 3060
Send, {d up}
Send, {s down}
Sleep, 760
Send, {s up}
Send, {d down}
Sleep, 230
Send, {d up}
}

PrePresequence() {
    CheckStop()
	HotbarMove()
    Send, {d down}
    SleepWithCheck(900)
    Send, {d up}
    Sleep, 50
    Send, {s down}
    SleepWithCheck(3300)
    Send, {s up}
    Sleep, 50
    Send, {a down}
    SleepWithCheck(600)
    Send, {a up}
    Sleep, 50
    Send, {e down}
    SleepWithCheck(100)
    Send, {e up}
    Sleep, 50
    SleepWithCheck(100)
    Send, {w}
    SleepWithCheck(100)
    FortuneTP()
NavigationSleep()
    Sleep, 50
	Loop 3 {
		Click
	}
    Sleep, 600
	HotbarMove()
}

PresequenceP() {
    CheckStop()
     Send, {w down}
    SleepWithCheck(600)
    Send, {w up}
    Sleep, 50
}

PresequenceTM() {
    CheckStop()
    Send, {d down}
    SleepWithCheck(600)
    Send, {d up}
    Sleep, 50
    Send, {s down}
    SleepWithCheck(5180)
    Send, {s up}
    Sleep, 50
    Send, {Left down}
    SleepWithCheck(700)
    Send, {Left up}
    Sleep, 50
    Send, {w down}
    SleepWithCheck(1500)
     Send, {w up}
    Sleep, 50
}

PostSequence() {
    CheckStop()
     SendReset()
}

BuyBasicLuck() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItemX2()
    Sleep, 50
}

BuyBasicCapacity() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
         Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItemX2()
    Sleep, 50
}

BuyGreaterLuck() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItemX2()

    Sleep, 50
}

BuyGreaterCapacity() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
         Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItemX2()
    Sleep, 50
}

BuyLuckTotem() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50 
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItem()
    Sleep, 50
}

BuyStrengthTotem() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
         Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItem()
    Sleep, 50
}

BuyMerchantsPotion() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItemX2()
    Sleep, 50
}

BuyVolcanicLuckPotion() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItem()
    Sleep, 50
}

BuyVolcanicStrengthPotion() {
    CheckStop()
    Sleep, 50 
	Loop 3 {
		Send, {e down}
        Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItem()
    Sleep, 50
}

BuySupremeLuckPotion() {
    CheckStop()
    Sleep, 50
	Loop 3 {
		Send, {e down}
        Sleep, 50
        Send, {e up}
        Sleep, 10
	}
    Sleep, 50
	BuyItem()
    Sleep, 50
}

MoveFromBasicToCapacity() {
    CheckStop() 
     Send, {d down}
    SleepWithCheck(320)
     Send, {d up}
    Sleep, 50
}

MoveFromBasicCapacityToGreaterLuck() {
    CheckStop()
    Send, {d down}
    SleepWithCheck(460)
    Send, {d up}
    Sleep, 50
}

MoveFromGreaterLuckToCapacity() {
    CheckStop()
    Send, {d down}
    SleepWithCheck(320)
    Send, {d up}
    Sleep, 50
}

MoveFromLuckToMerchant() {
    CheckStop()
    Send, {d down}
    SleepWithCheck(420)
    Send, {d up}
    Sleep, 50 
     Send, {w down}
    SleepWithCheck(390)
     Send, {w up}
    Sleep, 50
}

MoveFromMerchantToStrength() {
    CheckStop()
    Send, {d down}
    Sleep, 500
    Send, {d up}
    Sleep, 50
    Send, {w down}
    Sleep, 1150
    Send, {w up}
}

MoveFromVolcanicLuckPotionToVolcanicStrengthPotion() {
    CheckStop()
Send, {d down}
Sleep, 300
Send, {d up}
return
}

MoveFromVolcanicStrengthPotionToSupremeLuckPotion() {
    CheckStop()
Send, {d down}
Sleep, 530
Send, {d up}
return
}

PlaceSingleLuckTotem() {
    Send, g
    Sleep, 100
	InvSearchBar()
    Sleep, 100
    Click
    Sleep, 100
    Send Luck Totem
    Sleep, 120
	InvTotemClick()
    Sleep, 100
    Click
     Sleep, 100
    Send, g
    Sleep, 120
    Click
    Sleep, 320
    Send, 1
    Sleep, 120
}

PlaceSingleStrengthTotem() {
    Send, g
    Sleep, 100
	InvSearchBar()
    Sleep, 100
    Click
    Sleep, 100
    Send Strength Totem 
     Sleep, 120
	InvTotemClick()
    Sleep, 100
    Click
    Sleep, 100
    Send, g
    Sleep, 120
    Click
     Sleep, 320
    Send, 1
    Sleep, 120
}

GetSelectedScriptNumber(locationName) {
    global scriptLabels
    Loop, % scriptLabels.MaxIndex() {
        if (locationName = scriptLabels[A_Index])
            return A_Index
    }
    return 1 
}

GetHoldTime(digSpeed) {
    if (digSpeed <= 0)
        digSpeed := 1
    ; FIXED: was SubStr(Round(...), 1, 3) - it takes the first three characters,
    ; so any 4-digit result (dig speeds below ~58) was silently cut to a tenth of
    ; its value and the dig hold came out ~10x too short. Full value, clamped so a
    ; bad stat cannot produce a 0 ms or silly hold.
    ms := Round(66900 / (digSpeed + 9))
    if (ms < 60)
        ms := 60
    if (ms > 4000)
        ms := 4000
    return ms
}

IsIH_Active() {
    FormatTime, UTCMinute, A_NowUTC, m
    ; Infernal Heart is active from minute 15 up to minute 42. (27 min duration)
    if (UTCMinute >= 15 and UTCMinute < 42) {
        return true
    }
    return false
}

IsVoidTimeViable() {
    global VOID_TEST_HOURLY, VOID_WINDOW_START_MIN_UTC, VOID_WINDOW_END_MIN_UTC

    utcNow := GetUtcNowStamp()

    FormatTime, UTCMinute, %utcNow%, m
    if (UTCMinute < VOID_WINDOW_START_MIN_UTC or UTCMinute >= VOID_WINDOW_END_MIN_UTC) {
        return false
    }

    if (VOID_TEST_HOURLY) {
        return true
    }

    FormatTime, UTCHour, %utcNow%, HH
    allowed := ",00,03,06,09,12,15,18,21,"
    if InStr(allowed, "," . UTCHour . ",") {
        return true
    }
    return false

}
SleepWithCheck(ms) {
    global running
    start := A_TickCount
    while (A_TickCount - start < ms) {
        if (!running)
            break
        Sleep, 50
    }
}

SendReset() {
    global ResetDelay
    CheckStop()
    Send, {Esc}
    SleepWithCheck(100)
    Loop 10 {
        Send, r
        Sleep, 10
    }
    Sleep, 100
    Loop 10 {
        Send, a
        Sleep, 10
    }
    Sleep, 100
    SleepWithCheck(100)
    Loop 10 {
         Send, {Enter}
        Sleep, 10
    }
    SleepWithCheck(ResetDelay * 1000)
    ClickDailyPrompt()
    Sleep, 300
}



ApplyHotkeys() {
    global StartHotkey, StopHotkey, OldStartHotkey, OldStopHotkey

    ; Turn off previous dynamic hotkeys (if they were set)
    if (OldStartHotkey != "")
        try Hotkey, ~%OldStartHotkey% up, Off
    if (OldStopHotkey != "")
        try Hotkey, %OldStopHotkey%, Off

    ; Re-apply dynamic hotkeys from the Hotkeys tab
    if (StartHotkey != "")
        Hotkey, ~%StartHotkey% up, StartMacro, On
    if (StopHotkey != "")
        Hotkey, %StopHotkey%, StopMacro, On


    ; Save for next apply
    OldStartHotkey := StartHotkey
    OldStopHotkey  := StopHotkey
}



LoadSettings() {
    global
    
    IniRead, AreaEnabled1, %settingsFile%, Locations, AreaEnabled1, 0
    IniRead, AreaSelection1, %settingsFile%, Locations, AreaSelection1, % scriptLabels[1]
	if (AreaSelection1 = "VOID") ; *** MODIFIED: Handle old settings with Void location ***
		AreaSelection1 := scriptLabels[1]
    IniRead, AreaDuration1, %settingsFile%, Locations, AreaDuration1, 60
    IniRead, AreaEnabled2, %settingsFile%, Locations, AreaEnabled2, 0
    IniRead, AreaSelection2, %settingsFile%, Locations, AreaSelection2, % scriptLabels[2]
	if (AreaSelection2 = "VOID") ; *** MODIFIED: Handle old settings with Void location ***
		AreaSelection2 := scriptLabels[2]
    IniRead, AreaDuration2, %settingsFile%, Locations, AreaDuration2, 60
    IniRead, AreaEnabled3, %settingsFile%, Locations, AreaEnabled3, 0
    IniRead, AreaSelection3, %settingsFile%, Locations, AreaSelection3, % scriptLabels[3]
	if (AreaSelection3 = "VOID") ; *** MODIFIED: Handle old settings with Void location ***
		AreaSelection3 := scriptLabels[3]
    IniRead, AreaDuration3, %settingsFile%, Locations, AreaDuration3, 60
    IniRead, EnableCustomLocation, %settingsFile%, CustomLocation, EnableCustomLocation, 0
    IniRead, EnableAutoSell, %settingsFile%, AutoSell, EnableAutoSell, 0
    IniRead, EnableInstantSell, %settingsFile%, AutoSell, EnableInstantSell, 0
    IniRead, DigspeedInput, %settingsFile%, Delays, DigspeedInput, 123
    IniRead, ResetDelay, %settingsFile%, Delays, ResetDelay, 13
    IniRead, MerchantDelay, %settingsFile%, Delays, MerchantDelay, 5
    IniRead, DiggingFallbackDelay, %settingsFile%, Delays, DiggingFallbackDelay, 30
    IniRead, PanningFallbackDelay, %settingsFile%, Delays, PanningFallbackDelay, 30
    IniRead, NavigationDelaySecs, %settingsFile%, Delays, NavigationDelaySecs, 0.3
    IniRead, StartHotkey, %settingsFile%, Hotkeys, Start, F6
    IniRead, StopHotkey, %settingsFile%, Hotkeys, Stop, F8
    IniRead, MainLoadout, %settingsFile%, Loadouts, MainLoadout, Loadout 1
    IniRead, SellLoadout, %settingsFile%, Loadouts, SellLoadout, Loadout 1
    IniRead, EnableLoadoutSwitcher, %settingsFile%, Loadouts, EnableLoadoutSwitcher, 0

    ; Load Buffs
    IniRead, RenewLuck, %settingsFile%, Buffs, RenewLuck, 0
    IniRead, LuckPotions, %settingsFile%, Buffs, LuckPotions, 0
    IniRead, RenewCapacity, %settingsFile%, Buffs, RenewCapacity, 0
    IniRead, CapacityPotions, %settingsFile%, Buffs, CapacityPotions, 0
    IniRead, RenewGreaterLuck, %settingsFile%, Buffs, RenewGreaterLuck, 0
    IniRead, GreaterLuckPotions, %settingsFile%, Buffs, GreaterLuckPotions, 0
    IniRead, RenewGreaterCapacity, %settingsFile%, Buffs, RenewGreaterCapacity, 0
    IniRead, GreaterCapacityPotions, %settingsFile%, Buffs, GreaterCapacityPotions, 0
    IniRead, RenewLuckTotem, %settingsFile%, Buffs, RenewLuckTotem, 0
    IniRead, LuckTotemCount, %settingsFile%, Buffs, LuckTotemCount, 0
    IniRead, LuckTotemOwned, %settingsFile%, Buffs, LuckTotemOwned, 0
    IniRead, RenewStrengthTotem, %settingsFile%, Buffs, RenewStrengthTotem, 0
    IniRead, StrengthTotemCount, %settingsFile%, Buffs, StrengthTotemCount, 0
    IniRead, StrengthTotemOwned, %settingsFile%, Buffs, StrengthTotemOwned, 0
    IniRead, RenewMerchantsPotion, %settingsFile%, Buffs, RenewMerchantsPotion, 0
    IniRead, MerchantsPotionCount, %settingsFile%, Buffs, MerchantsPotionCount, 0
    IniRead, RenewVolcanicLuck, %settingsFile%, Buffs, RenewVolcanicLuck, 0
    IniRead, VolcanicLuckPotionCount, %settingsFile%, Buffs, VolcanicLuckPotionCount, 0
    IniRead, RenewVolcanicStrength, %settingsFile%, Buffs, RenewVolcanicStrength, 0
    IniRead, VolcanicStrengthPotionCount, %settingsFile%, Buffs, VolcanicStrengthPotionCount, 0
    IniRead, RenewSupremeLuck, %settingsFile%, Buffs, RenewSupremeLuck, 0
    IniRead, SupremeLuckPotionCount, %settingsFile%, Buffs, SupremeLuckPotionCount, 0

    IniRead, TimedEventPriority_String, %settingsFile%, General, TimedEventPriority, VOID

	; *** MODIFIED: Handle loading "VOID" priority from settings ***
	if (TimedEventPriority_String = "VOID")
	{
		GuiControl,, PriorityIH, 1
	}
	else
	{
		GuiControl,, PriorityIH, 1
	}

    activeAreaSelection1 := AreaSelection1
    activeAreaSelection2 := AreaSelection2
    activeAreaSelection3 := AreaSelection3

    GuiControl,, DigspeedInput, %DigspeedInput%
    GuiControl,, ResetDelay, %ResetDelay%
    GuiControl,, MerchantDelay, %MerchantDelay%
    GuiControl,, AreaEnabled1, %AreaEnabled1%
    GuiControl, Choose, AreaSelection1, %AreaSelection1%
    GuiControl,, AreaDuration1, %AreaDuration1%
    GuiControl,, AreaEnabled2, %AreaEnabled2% 
    GuiControl, Choose, AreaSelection2, %AreaSelection2%
    GuiControl,, AreaDuration2, %AreaDuration2%
    GuiControl,, AreaEnabled3, %AreaEnabled3%
    GuiControl, Choose, AreaSelection3, %AreaSelection3%
    GuiControl,, AreaDuration3, %AreaDuration3%
    GuiControl,, EnableCustomLocation, %EnableCustomLocation%
    GuiControl,, EnableAutoSell, %EnableAutoSell%
    GuiControl,, EnableInstantSell, %EnableInstantSell%
    GuiControl,, DiggingFallbackDelay, %DiggingFallbackDelay%
    GuiControl,, PanningFallbackDelay, %PanningFallbackDelay%
    GuiControl,, NavigationDelaySecs, %NavigationDelaySecs%
    GuiControl,, StartHotkey, %StartHotkey%
    GuiControl,, StopHotkey, %StopHotkey%
    GuiControl,, EnableLoadoutSwitcher, %EnableLoadoutSwitcher%
    GuiControl, Choose, MainLoadout, %MainLoadout%
    GuiControl, Choose, SellLoadout, %SellLoadout%


    ; Update Buffs GUI
    GuiControl,, RenewLuck, %RenewLuck%
    GuiControl,, LuckPotions, %LuckPotions%
    GuiControl,, RenewCapacity, %RenewCapacity%
    GuiControl,, CapacityPotions, %CapacityPotions%
    GuiControl,, RenewGreaterLuck, %RenewGreaterLuck%
    GuiControl,, GreaterLuckPotions, %GreaterLuckPotions%
    GuiControl,, RenewGreaterCapacity, %RenewGreaterCapacity%
    GuiControl,, GreaterCapacityPotions, %GreaterCapacityPotions%
    GuiControl,, RenewLuckTotem, %RenewLuckTotem%
    GuiControl,, LuckTotemCount, %LuckTotemCount%
    GuiControl,, LuckTotemOwned, %LuckTotemOwned%
    GuiControl,, RenewStrengthTotem, %RenewStrengthTotem%
    GuiControl,, StrengthTotemCount, %StrengthTotemCount%
    GuiControl,, StrengthTotemOwned, %StrengthTotemOwned%
    GuiControl,, RenewMerchantsPotion, %RenewMerchantsPotion%
    GuiControl,, MerchantsPotionCount, %MerchantsPotionCount%
    GuiControl,, RenewVolcanicLuck, %RenewVolcanicLuck%
    GuiControl,, VolcanicLuckPotionCount, %VolcanicLuckPotionCount%
    GuiControl,, RenewVolcanicStrength, %RenewVolcanicStrength%
    GuiControl,, VolcanicStrengthPotionCount, %VolcanicStrengthPotionCount%
    GuiControl,, RenewSupremeLuck, %RenewSupremeLuck%
    GuiControl,, SupremeLuckPotionCount, %SupremeLuckPotionCount%

    Gui, Submit, NoHide

    GoSub, ToggleAutoSell
    GoSub, ToggleInstantSell
    GoSub, ToggleLoadoutSwitcher
    
    if (EnableCustomLocation) {
         GoSub, ToggleCustomLocation
    }
    
    GoSub, UpdateLocationControls
    ApplyHotkeys()
}

SaveSettings() {
    global
    
    Gui, Submit, NoHide

    if (PriorityVoid)
        TimedEventPriority_String := "VOID"
    else
        TimedEventPriority_String := "INFERNAL HEART"

    IniWrite, %AreaEnabled1%, %settingsFile%, Locations, AreaEnabled1
    IniWrite, %AreaSelection1%, %settingsFile%, Locations, AreaSelection1
    IniWrite, %AreaDuration1%, %settingsFile%, Locations, AreaDuration1
    IniWrite, %AreaEnabled2%, %settingsFile%, Locations, AreaEnabled2
    IniWrite, %AreaSelection2%, %settingsFile%, Locations, AreaSelection2
    IniWrite, %AreaDuration2%, %settingsFile%, Locations, AreaDuration2
    IniWrite, %AreaEnabled3%, %settingsFile%, Locations, AreaEnabled3
    IniWrite, %AreaSelection3%, %settingsFile%, Locations, AreaSelection3
    IniWrite, %AreaDuration3%, %settingsFile%, Locations, AreaDuration3
    IniWrite, %EnableCustomLocation%, %settingsFile%, CustomLocation, EnableCustomLocation
    IniWrite, %EnableAutoSell%, %settingsFile%, AutoSell, EnableAutoSell
    IniWrite, %EnableInstantSell%, %settingsFile%, AutoSell, EnableInstantSell
    IniWrite, %MainLoadout%, %settingsFile%, Loadouts, MainLoadout
    IniWrite, %SellLoadout%, %settingsFile%, Loadouts, SellLoadout
    IniWrite, %EnableLoadoutSwitcher%, %settingsFile%, Loadouts, EnableLoadoutSwitcher
    IniWrite, %DigspeedInput%, %settingsFile%, Delays, DigspeedInput
    IniWrite, %ResetDelay%, %settingsFile%, Delays, ResetDelay
    IniWrite, %MerchantDelay%, %settingsFile%, Delays, MerchantDelay
    IniWrite, %DiggingFallbackDelay%, %settingsFile%, Delays, DiggingFallbackDelay 
    IniWrite, %PanningFallbackDelay%, %settingsFile%, Delays, PanningFallbackDelay
    IniWrite, %NavigationDelaySecs%, %settingsFile%, Delays, NavigationDelaySecs
    IniWrite, %TimedEventPriority_String%, %settingsFile%, General, TimedEventPriority
    IniWrite, %StartHotkey%, %settingsFile%, Hotkeys, Start
    IniWrite, %StopHotkey%, %settingsFile%, Hotkeys, Stop

    ; Save Buffs
    IniWrite, %RenewLuck%, %settingsFile%, Buffs, RenewLuck
    IniWrite, %LuckPotions%, %settingsFile%, Buffs, LuckPotions
    IniWrite, %RenewCapacity%, %settingsFile%, Buffs, RenewCapacity
    IniWrite, %CapacityPotions%, %settingsFile%, Buffs, CapacityPotions
    IniWrite, %RenewGreaterLuck%, %settingsFile%, Buffs, RenewGreaterLuck
    IniWrite, %GreaterLuckPotions%, %settingsFile%, Buffs, GreaterLuckPotions
    IniWrite, %RenewGreaterCapacity%, %settingsFile%, Buffs, RenewGreaterCapacity
    IniWrite, %GreaterCapacityPotions%, %settingsFile%, Buffs, GreaterCapacityPotions
    IniWrite, %RenewLuckTotem%, %settingsFile%, Buffs, RenewLuckTotem
    IniWrite, %LuckTotemCount%, %settingsFile%, Buffs, LuckTotemCount
    IniWrite, %LuckTotemOwned%, %settingsFile%, Buffs, LuckTotemOwned
    IniWrite, %RenewStrengthTotem%, %settingsFile%, Buffs, RenewStrengthTotem
    IniWrite, %StrengthTotemCount%, %settingsFile%, Buffs, StrengthTotemCount
    IniWrite, %StrengthTotemOwned%, %settingsFile%, Buffs, StrengthTotemOwned
    IniWrite, %RenewMerchantsPotion%, %settingsFile%, Buffs, RenewMerchantsPotion
    IniWrite, %MerchantsPotionCount%, %settingsFile%, Buffs, MerchantsPotionCount
    IniWrite, %RenewVolcanicLuck%, %settingsFile%, Buffs, RenewVolcanicLuck
    IniWrite, %VolcanicLuckPotionCount%, %settingsFile%, Buffs, VolcanicLuckPotionCount
    IniWrite, %RenewVolcanicStrength%, %settingsFile%, Buffs, RenewVolcanicStrength
    IniWrite, %VolcanicStrengthPotionCount%, %settingsFile%, Buffs, VolcanicStrengthPotionCount
    IniWrite, %RenewSupremeLuck%, %settingsFile%, Buffs, RenewSupremeLuck
    IniWrite, %SupremeLuckPotionCount%, %settingsFile%, Buffs, SupremeLuckPotionCount

    ApplyHotkeys()
}


; Emergency stop hotkey
F8::Gosub, StopMacro

