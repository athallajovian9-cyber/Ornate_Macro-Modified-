#Requires AutoHotkey v1.1
#NoTrayIcon
#Persistent
#SingleInstance Force
CoordMode, Pixel, Window
CoordMode, Mouse, Window
#Include %A_ScriptDir%\helpers.ahk
global navigationDelay := A_Args.Length() >= 2 ? A_Args[2] : 300

NavigationSleep() {
    global navigationDelay
    Sleep, %navigationDelay%
}

SendMode, Event

if (A_Args.Length() >= 1) {
    digspeed := A_Args[1]
} else {
    digspeed := 123
}

; === MAIN HERE ===
Send, {w up}{a up}{s up}{d up}{LButton up}{Space up}{Left up}{Right up}
HotbarMove()
Send, {d down}
Sleep, 900
Send, {d up}
Send, {s down}
Sleep, 3300
Send, {s up}
Send, {a down}
Sleep, 600
Send, {a up}
Send, {e down}
Sleep, 100
Send, {e up}
Sleep, 100
Send, {w}
Sleep, 100
FrostbiteRiverTP()
Sleep, 50
HotbarMove()
NavigationSleep()
Send, {w down}
Sleep, 3500
Send, {w up}
Send, {1}


; ===============

ExitApp  ; terminate script12 cleanly
