#Requires AutoHotkey v1.1
#NoTrayIcon
#Persistent
#SingleInstance Force
CoordMode, Pixel, Window
CoordMode, Mouse, Window
#Include %A_ScriptDir%\helpers.ahk
global navigationDelay := A_Args.Length() >= 2 ? A_Args[2] : 300

NavigationSleep() {
    global navigationDelay
    Sleep, %navigationDelay%
}

SendMode, Event

if (A_Args.Length() >= 1) {
    digspeed := A_Args[1]
} else {
    digspeed := 123
}

; === MAIN HERE ===
Send, {w up}{a up}{s up}{d up}{LButton up}{Space up}{Left up}{Right up}
HotbarMove()
Send, {d down}
Sleep, 900
Send, {d up}
Sleep, 30
Send, {s down}
Sleep, 3300
Send, {s up}
Sleep, 30
Send, {a down}
Sleep, 600
Send, {a up}
Sleep, 30
Send, {e down}
Sleep, 100
Send, {e up}
Sleep, 100
Send, {w}
Sleep, 100
VolcanicSandsTP()
Sleep, 50
HotbarMove()
NavigationSleep()
Send, {1}
Send, {a down}
Sleep, 6900
Send, {a up}
Sleep, 30
Send, {Left down}
Sleep, 690
Send, {Left up}

; ===============

ExitApp  ; terminate script8 cleanly



