#Requires AutoHotkey v1.1
#SingleInstance, Force
; double click this script starts Controller.ahk (actual macro)
#Include %A_ScriptDir%\Modules\CurrentVersion.ahk

CheckForUpdate()

Run, %A_ScriptDir%\Modules\Controller.ahk
Return

; #############################################
; ##                HOTKEYS                  ##
; ############################################






; --- Helpers ---
